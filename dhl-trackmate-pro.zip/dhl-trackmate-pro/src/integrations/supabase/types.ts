export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      scheduled_updates: {
        Row: {
          applied_at: string | null
          created_at: string
          created_by: string | null
          id: string
          lat: number | null
          lng: number | null
          location_name: string | null
          notes: string | null
          scheduled_for: string
          shipment_id: string
          status: string | null
        }
        Insert: {
          applied_at?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          lat?: number | null
          lng?: number | null
          location_name?: string | null
          notes?: string | null
          scheduled_for: string
          shipment_id: string
          status?: string | null
        }
        Update: {
          applied_at?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          lat?: number | null
          lng?: number | null
          location_name?: string | null
          notes?: string | null
          scheduled_for?: string
          shipment_id?: string
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scheduled_updates_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      shipments: {
        Row: {
          animation_easing: string
          animation_smoothness: string
          created_at: string
          created_by: string | null
          current_lat: number | null
          current_lng: number | null
          current_location_name: string | null
          destination: string | null
          estimated_delivery: string | null
          id: string
          origin: string | null
          package_description: string | null
          recipient_address: string | null
          recipient_name: string | null
          route_completed: boolean
          route_duration_seconds: number | null
          route_elapsed_seconds: number
          route_from_lat: number | null
          route_from_lng: number | null
          route_from_name: string | null
          route_history: Json
          route_paused: boolean
          route_started_at: string | null
          route_to_lat: number | null
          route_to_lng: number | null
          route_to_name: string | null
          sender_name: string | null
          status: string
          tracking_number: string
          updated_at: string
          weight_kg: number | null
        }
        Insert: {
          animation_easing?: string
          animation_smoothness?: string
          created_at?: string
          created_by?: string | null
          current_lat?: number | null
          current_lng?: number | null
          current_location_name?: string | null
          destination?: string | null
          estimated_delivery?: string | null
          id?: string
          origin?: string | null
          package_description?: string | null
          recipient_address?: string | null
          recipient_name?: string | null
          route_completed?: boolean
          route_duration_seconds?: number | null
          route_elapsed_seconds?: number
          route_from_lat?: number | null
          route_from_lng?: number | null
          route_from_name?: string | null
          route_history?: Json
          route_paused?: boolean
          route_started_at?: string | null
          route_to_lat?: number | null
          route_to_lng?: number | null
          route_to_name?: string | null
          sender_name?: string | null
          status?: string
          tracking_number: string
          updated_at?: string
          weight_kg?: number | null
        }
        Update: {
          animation_easing?: string
          animation_smoothness?: string
          created_at?: string
          created_by?: string | null
          current_lat?: number | null
          current_lng?: number | null
          current_location_name?: string | null
          destination?: string | null
          estimated_delivery?: string | null
          id?: string
          origin?: string | null
          package_description?: string | null
          recipient_address?: string | null
          recipient_name?: string | null
          route_completed?: boolean
          route_duration_seconds?: number | null
          route_elapsed_seconds?: number
          route_from_lat?: number | null
          route_from_lng?: number | null
          route_from_name?: string | null
          route_history?: Json
          route_paused?: boolean
          route_started_at?: string | null
          route_to_lat?: number | null
          route_to_lng?: number | null
          route_to_name?: string | null
          sender_name?: string | null
          status?: string
          tracking_number?: string
          updated_at?: string
          weight_kg?: number | null
        }
        Relationships: []
      }
      tracking_events: {
        Row: {
          created_at: string
          id: string
          lat: number | null
          lng: number | null
          location_name: string | null
          notes: string | null
          shipment_id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          lat?: number | null
          lng?: number | null
          location_name?: string | null
          notes?: string | null
          shipment_id: string
          status: string
        }
        Update: {
          created_at?: string
          id?: string
          lat?: number | null
          lng?: number | null
          location_name?: string | null
          notes?: string | null
          shipment_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "tracking_events_shipment_id_fkey"
            columns: ["shipment_id"]
            isOneToOne: false
            referencedRelation: "shipments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_clear_auto_route: {
        Args: { _shipment_id: string }
        Returns: undefined
      }
      admin_pause_auto_route: {
        Args: { _shipment_id: string }
        Returns: undefined
      }
      admin_reroute_destination: {
        Args: {
          _destination_text?: string
          _duration_seconds: number
          _shipment_id: string
          _to_lat: number
          _to_lng: number
          _to_name: string
        }
        Returns: undefined
      }
      admin_resume_auto_route: {
        Args: { _shipment_id: string }
        Returns: undefined
      }
      admin_set_animation_easing: {
        Args: { _easing: string; _shipment_id: string }
        Returns: undefined
      }
      admin_set_animation_smoothness: {
        Args: { _shipment_id: string; _smoothness: string }
        Returns: undefined
      }
      admin_set_auto_route: {
        Args: {
          _duration_seconds: number
          _from_lat: number
          _from_lng: number
          _from_name: string
          _shipment_id: string
          _start_now?: boolean
          _to_lat: number
          _to_lng: number
          _to_name: string
        }
        Returns: undefined
      }
      admin_update_shipment: {
        Args: {
          _estimated_delivery?: string
          _lat?: number
          _lng?: number
          _location_name?: string
          _location_provided?: boolean
          _notes?: string
          _set_estimated_delivery?: boolean
          _shipment_id: string
          _status?: string
        }
        Returns: Json
      }
      get_shipment_by_tracking: { Args: { _tracking: string }; Returns: Json }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      process_scheduled_updates: { Args: never; Returns: number }
      tick_auto_routes: { Args: never; Returns: number }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
