import { createServerFn } from "@tanstack/react-start";
import { decodePolyline, haversineMeters, simplifyPoints, type LatLngPoint } from "./route.server";

export type RouteMode = "road" | "flight";

export interface ShipmentRoutePath {
  mode: RouteMode;
  points: LatLngPoint[];
  reason?: string;
}

interface RouteInput {
  fromLat: number;
  fromLng: number;
  toLat: number;
  toLng: number;
}

/**
 * Resolves the real transport path between two coordinates.
 * Returns a road polyline when a drivable connection exists; otherwise
 * returns mode "flight" with no points so the client draws a geodesic arc.
 */
export const getShipmentRoute = createServerFn({ method: "POST" })
  .inputValidator((data: RouteInput) => {
    const nums = [data?.fromLat, data?.fromLng, data?.toLat, data?.toLng];
    if (!nums.every((n) => typeof n === "number" && Number.isFinite(n))) {
      throw new Error("Invalid coordinates");
    }
    if (Math.abs(data.fromLat) > 90 || Math.abs(data.toLat) > 90) throw new Error("Invalid latitude");
    if (Math.abs(data.fromLng) > 180 || Math.abs(data.toLng) > 180) throw new Error("Invalid longitude");
    return {
      fromLat: data.fromLat,
      fromLng: data.fromLng,
      toLat: data.toLat,
      toLng: data.toLng,
    };
  })
  .handler(async ({ data }): Promise<ShipmentRoutePath> => {
    const lovableKey = process.env.LOVABLE_API_KEY;
    const mapsKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!lovableKey || !mapsKey) {
      return { mode: "flight", points: [], reason: "maps-credentials-missing" };
    }

    try {
      const res = await fetch(
        "https://connector-gateway.lovable.dev/google_maps/routes/directions/v2:computeRoutes",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${lovableKey}`,
            "X-Connection-Api-Key": mapsKey,
            "Content-Type": "application/json",
            "X-Goog-FieldMask":
              "routes.polyline.encodedPolyline,routes.distanceMeters,routes.travelAdvisory",
          },
          body: JSON.stringify({
            origin: { location: { latLng: { latitude: data.fromLat, longitude: data.fromLng } } },
            destination: { location: { latLng: { latitude: data.toLat, longitude: data.toLng } } },
            travelMode: "DRIVE",
            polylineQuality: "HIGH_QUALITY",
            routeModifiers: { avoidFerries: true },
          }),
        },
      );

      if (!res.ok) {
        const body = await res.text();
        console.error(`Routes API failed [${res.status}]: ${body}`);
        // No drivable connection (e.g. across an ocean) also lands here.
        return { mode: "flight", points: [], reason: `routes-${res.status}` };
      }

      const json = (await res.json()) as {
        routes?: Array<{
          polyline?: { encodedPolyline?: string };
          distanceMeters?: number;
          travelAdvisory?: { routeRestrictionsPartiallyIgnored?: boolean };
        }>;
      };
      const route = json.routes?.[0];
      const encoded = route?.polyline?.encodedPolyline;
      if (!encoded) return { mode: "flight", points: [], reason: "no-road-route" };

      // A "drivable" result that only works by ignoring the no-ferry
      // restriction means the two points aren't connected by land.
      if (route?.travelAdvisory?.routeRestrictionsPartiallyIgnored) {
        return { mode: "flight", points: [], reason: "ferry-required" };
      }

      // Absurd detour ratio => no sensible land connection, fly instead.
      const straight = haversineMeters(data.fromLat, data.fromLng, data.toLat, data.toLng);
      const roadMeters = route?.distanceMeters ?? 0;
      if (straight > 1000 && roadMeters > straight * 4) {
        return { mode: "flight", points: [], reason: "detour-ratio" };
      }

      const points = simplifyPoints(decodePolyline(encoded));
      if (points.length < 2) return { mode: "flight", points: [], reason: "empty-road-route" };
      return { mode: "road", points };
    } catch (error) {
      console.error("Routes API request error", error);
      return { mode: "flight", points: [], reason: "routes-error" };
    }
  });

