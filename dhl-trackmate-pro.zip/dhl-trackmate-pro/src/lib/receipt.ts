import jsPDF from "jspdf";
import { format } from "date-fns";

interface Event {
  status: string;
  location_name: string | null;
  notes: string | null;
  created_at: string;
}

interface Shipment {
  tracking_number: string;
  status: string;
  sender_name: string | null;
  recipient_name: string | null;
  recipient_address: string | null;
  origin: string | null;
  destination: string | null;
  package_description: string | null;
  weight_kg: number | null;
  current_location_name: string | null;
  estimated_delivery: string | null;
  created_at: string;
  events: Event[];
}

export function downloadReceipt(s: Shipment) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  let y = 40;

  // Header band
  doc.setFillColor(255, 204, 0);
  doc.rect(0, 0, W, 70, "F");
  doc.setTextColor(20, 20, 20);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.text("DHL", 40, 45);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("Delivery Service — Shipment Receipt", 90, 45);

  y = 110;
  doc.setTextColor(20, 20, 20);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("TRACKING NUMBER", 40, y);
  doc.setFontSize(18);
  doc.text(s.tracking_number, 40, y + 22);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Status: ${s.status}`, 40, y + 42);
  if (s.estimated_delivery) {
    doc.text(
      `Estimated delivery: ${format(new Date(s.estimated_delivery), "PPP")}`,
      40,
      y + 58,
    );
  }
  doc.text(`Issued: ${format(new Date(), "PPpp")}`, 40, y + 74);

  y += 100;
  doc.setDrawColor(220);
  doc.line(40, y, W - 40, y);
  y += 20;

  // Details
  const rows: Array<[string, string]> = [
    ["Sender", s.sender_name ?? "—"],
    ["Recipient", s.recipient_name ?? "—"],
    ["Recipient Address", s.recipient_address ?? "—"],
    ["Origin", s.origin ?? "—"],
    ["Destination", s.destination ?? "—"],
    ["Current Location", s.current_location_name ?? "—"],
    ["Package", s.package_description ?? "—"],
    ["Weight", s.weight_kg ? `${s.weight_kg} kg` : "—"],
    ["Shipment Date", format(new Date(s.created_at), "PPP")],
  ];

  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("Shipment Details", 40, y);
  y += 18;
  doc.setFontSize(10);

  rows.forEach(([k, v]) => {
    doc.setFont("helvetica", "bold");
    doc.text(k, 40, y);
    doc.setFont("helvetica", "normal");
    const lines = doc.splitTextToSize(v, W - 220);
    doc.text(lines, 200, y);
    y += Math.max(16, lines.length * 14);
    if (y > 760) {
      doc.addPage();
      y = 60;
    }
  });

  y += 10;
  doc.setDrawColor(220);
  doc.line(40, y, W - 40, y);
  y += 20;

  // History
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text("Tracking History", 40, y);
  y += 18;
  doc.setFontSize(10);

  s.events.forEach((e) => {
    if (y > 760) {
      doc.addPage();
      y = 60;
    }
    doc.setFont("helvetica", "bold");
    doc.text(e.status, 40, y);
    doc.setFont("helvetica", "normal");
    doc.text(format(new Date(e.created_at), "PPpp"), W - 40, y, {
      align: "right",
    });
    y += 14;
    if (e.location_name) {
      doc.setTextColor(90);
      doc.text(e.location_name, 40, y);
      doc.setTextColor(20);
      y += 14;
    }
    if (e.notes) {
      const noteLines = doc.splitTextToSize(e.notes, W - 80);
      doc.setTextColor(120);
      doc.text(noteLines, 40, y);
      doc.setTextColor(20);
      y += noteLines.length * 12;
    }
    y += 6;
  });

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(140);
  doc.text(
    "This is an official tracking receipt from DHL Delivery Service.",
    W / 2,
    820,
    { align: "center" },
  );

  doc.save(`DHL-Receipt-${s.tracking_number}.pdf`);
}
