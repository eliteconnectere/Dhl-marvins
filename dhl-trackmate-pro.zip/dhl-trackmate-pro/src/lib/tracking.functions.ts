import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

type Row = Record<string, unknown>;

interface TrackingEvent {
  id: string;
  status: string;
  location_name: string | null;
  lat: number | null;
  lng: number | null;
  notes: string | null;
  created_at: string;
}

function normalize(shipment: Row) {
  const g = <T,>(k: string, fallback: T): T => (shipment[k] ?? fallback) as T;
  return {
    id: shipment.id as string,
    tracking_number: shipment.tracking_number as string,
    status: shipment.status as string,
    sender_name: g<string | null>("sender_name", null),
    recipient_name: g<string | null>("recipient_name", null),
    recipient_address: g<string | null>("recipient_address", null),
    origin: g<string | null>("origin", null),
    destination: g<string | null>("destination", null),
    package_description: g<string | null>("package_description", null),
    weight_kg: g<number | null>("weight_kg", null),
    current_location_name: g<string | null>("current_location_name", null),
    current_lat: g<number | null>("current_lat", null),
    current_lng: g<number | null>("current_lng", null),
    estimated_delivery: g<string | null>("estimated_delivery", null),
    created_at: shipment.created_at as string,
    updated_at: shipment.updated_at as string,
    route_from_lat: g<number | null>("route_from_lat", null),
    route_from_lng: g<number | null>("route_from_lng", null),
    route_from_name: g<string | null>("route_from_name", null),
    route_to_lat: g<number | null>("route_to_lat", null),
    route_to_lng: g<number | null>("route_to_lng", null),
    route_to_name: g<string | null>("route_to_name", null),
    route_duration_seconds: g<number | null>("route_duration_seconds", null),
    route_started_at: g<string | null>("route_started_at", null),
    route_elapsed_seconds: g<number>("route_elapsed_seconds", 0),
    route_paused: g<boolean>("route_paused", false),
    route_completed: g<boolean>("route_completed", false),
    animation_smoothness: g<"fluid" | "standard" | "instant">("animation_smoothness", "fluid"),
    animation_easing: g<"linear" | "ease-in-out" | "ease-out">("animation_easing", "linear"),
    // Permanent journey history: completed legs (original origin -> ... -> current).
    // Never derived from the current location; it is stored per reroute.
    route_history: g<
      {
        from_lat: number;
        from_lng: number;
        from_name?: string | null;
        to_lat: number;
        to_lng: number;
        to_name?: string | null;
      }[]
    >("route_history", []) ?? [],
    events: g<TrackingEvent[]>("events", []) ?? [],
  };
}

export const getPublicShipment = createServerFn({ method: "GET" })
  .inputValidator(z.object({ tracking: z.string().min(1).max(64) }))
  .handler(async ({ data }) => {
    const tracking = data.tracking.trim().toUpperCase();

    // Public lookup: uses the publishable (anon) key + a SECURITY DEFINER
    // database function, so it works for guests on any device/browser and
    // never depends on a server-only service-role key being present.
    //
    // NOTE: these MUST be dot-access reads — the build pins the project's own
    // Supabase URL/key by replacing `process.env.SUPABASE_URL` literally.
    // Bracket access (process.env["SUPABASE_URL"]) is NOT replaced and falls
    // back to the hosting platform's own (wrong) backend at runtime, which is
    // what made valid tracking codes report "not found" on guest devices.
    const url = process.env.SUPABASE_URL as string;
    const key = (process.env.SUPABASE_PUBLISHABLE_KEY ||
      process.env.SUPABASE_ANON_KEY) as string;

    const supabasePublic = createClient(url, key, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    });

    const { data: result, error } = await supabasePublic.rpc("get_shipment_by_tracking", {
      _tracking: tracking,
    });

    if (error) throw error;
    if (!result) return null;

    return normalize(result as Row);
  });
