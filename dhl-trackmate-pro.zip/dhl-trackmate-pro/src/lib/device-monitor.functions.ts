import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

const Input = z.object({
  deviceId: z.string().min(8).max(80),
  deviceType: z.string().max(40),
  os: z.string().max(40),
  browser: z.string().max(40),
  timezone: z.string().max(60).optional(),
  language: z.string().max(20).optional(),
  screen: z.string().max(20).optional(),
  page: z.string().max(200).optional(),
});

let regionNames: Intl.DisplayNames | null = null;
function countryName(code: string | null): string | null {
  if (!code || code === "XX" || code === "T1" || code.length !== 2) return null;
  try {
    regionNames ??= new Intl.DisplayNames(["en"], { type: "region" });
    return regionNames.of(code.toUpperCase()) ?? code;
  } catch {
    return code;
  }
}

// Public: records an anonymous visit. Location comes from the hosting edge (country/region only).
export const reportDeviceVisit = createServerFn({ method: "POST" })
  .inputValidator((d) => Input.parse(d))
  .handler(async ({ data }) => {
    try {
      const req = getRequest() as Request & { cf?: Record<string, unknown> };
      const cf = req?.cf ?? {};
      const h = req?.headers;
      const code = (cf.country as string) || h?.get("cf-ipcountry") || null;
      const region = (cf.region as string) || h?.get("cf-region") || null;
      const city = (cf.city as string) || h?.get("cf-ipcity") || null;
      const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
      const sb = createClient(process.env.SUPABASE_URL!, key, {
        auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
      });
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (sb.rpc as any)("record_device_visit", {
        _device_id: data.deviceId,
        _device_type: data.deviceType,
        _os: data.os,
        _browser: data.browser,
        _country: countryName(code),
        _region: region,
        _city: city,
        _timezone: data.timezone ?? null,
        _language: data.language ?? null,
        _screen: data.screen ?? null,
        _page: data.page ?? null,
      });
    } catch (e) {
      console.error("device visit report failed", e);
    }
    return { ok: true };
  });
