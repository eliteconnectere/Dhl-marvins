import { geocodeAddress } from "./geocode.functions";

export interface GeocodeResult {
  display_name: string;
  lat: number;
  lng: number;
}

/**
 * Address lookup for every user, resolved on the server (Google Geocoding with an
 * OpenStreetMap fallback). Previously this called OpenStreetMap directly from the
 * browser, which is rate-limited/blocked on many mobile networks — that made the
 * result depend on the device instead of the address.
 */
export async function geocode(query: string): Promise<GeocodeResult[]> {
  const trimmed = query.trim();
  if (!trimmed) return [];

  try {
    const res = await geocodeAddress({ data: { query: trimmed } });
    if (res.results.length === 0 && res.error) throw new Error(res.error);
    return res.results;
  } catch (error) {
    if (error instanceof Error) throw error;
    throw new Error("Location search failed. Please try a more specific address.");
  }
}
