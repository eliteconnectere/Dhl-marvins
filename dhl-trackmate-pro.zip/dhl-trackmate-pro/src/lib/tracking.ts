export function generateTrackingNumber(): string {
  // DHL-style: 10 digits prefixed with "DHL"
  const digits = Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
  return `DHL${digits}`;
}

export const SHIPMENT_STATUSES = [
  "Shipment Created",
  "Package Received",
  "Processing",
  "In Transit",
  "Arrived at Facility",
  "Out for Delivery",
  "Delivered",
  "Completed",
] as const;

export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];
