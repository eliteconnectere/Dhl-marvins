import { createServerFn } from "@tanstack/react-start";

export interface GeocodeHit {
  display_name: string;
  lat: number;
  lng: number;
}

export interface GeocodeResponse {
  results: GeocodeHit[];
  provider: "google" | "nominatim" | "none";
  error?: string;
}

async function googleGeocode(query: string, key: string): Promise<GeocodeHit[]> {
  const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(query)}&key=${key}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Geocoding service error (${res.status})`);
  const json = (await res.json()) as {
    status: string;
    error_message?: string;
    results?: Array<{ formatted_address: string; geometry: { location: { lat: number; lng: number } } }>;
  };
  if (json.status === "ZERO_RESULTS") return [];
  if (json.status !== "OK") {
    throw new Error(json.error_message || `Geocoding failed (${json.status})`);
  }
  return (json.results ?? [])
    .slice(0, 5)
    .map((r) => ({
      display_name: r.formatted_address,
      lat: r.geometry.location.lat,
      lng: r.geometry.location.lng,
    }))
    .filter((r) => Number.isFinite(r.lat) && Number.isFinite(r.lng));
}

async function nominatimGeocode(query: string): Promise<GeocodeHit[]> {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: { Accept: "application/json", "User-Agent": "dhl-trackmate/1.0 (shipment tracking)" },
  });
  if (!res.ok) throw new Error(`Location search failed (${res.status})`);
  const data = (await res.json()) as Array<{ display_name: string; lat: string; lon: string }>;
  return data
    .map((d) => ({ display_name: d.display_name, lat: parseFloat(d.lat), lng: parseFloat(d.lon) }))
    .filter((d) => Number.isFinite(d.lat) && Number.isFinite(d.lng));
}

/**
 * Server-side address lookup. Runs from the server for every user, so results no
 * longer depend on the phone, carrier IP, or browser CORS behaviour.
 */
export const geocodeAddress = createServerFn({ method: "POST" })
  .inputValidator((data: { query: string }) => ({ query: String(data?.query ?? "") }))
  .handler(async ({ data }): Promise<GeocodeResponse> => {
    const query = data.query.trim();
    if (!query) return { results: [], provider: "none" };

    const key = process.env.GOOGLE_MAPS_API_KEY;
    let lastError: string | undefined;

    if (key) {
      try {
        const results = await googleGeocode(query, key);
        console.log(`[geocode] google "${query}" -> ${results.length} result(s)`);
        if (results.length > 0) return { results, provider: "google" };
      } catch (err) {
        lastError = err instanceof Error ? err.message : "Geocoding failed";
        console.error(`[geocode] google failed for "${query}": ${lastError}`);
      }
    }

    try {
      const results = await nominatimGeocode(query);
      console.log(`[geocode] nominatim "${query}" -> ${results.length} result(s)`);
      return { results, provider: results.length ? "nominatim" : "none", error: lastError };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Location search failed";
      console.error(`[geocode] nominatim failed for "${query}": ${message}`);
      return { results: [], provider: "none", error: lastError ?? message };
    }
  });
