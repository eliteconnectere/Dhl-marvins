// Lightweight country extraction & comparison helpers.
// Uses simple heuristics on free-text addresses / Nominatim display_name strings.

const COUNTRY_ALIASES: Record<string, string> = {
  usa: "united states",
  us: "united states",
  "u.s.": "united states",
  "u.s.a.": "united states",
  america: "united states",
  uk: "united kingdom",
  britain: "united kingdom",
  england: "united kingdom",
  uae: "united arab emirates",
  prc: "china",
  "p.r.c.": "china",
};

const KNOWN_COUNTRIES = [
  "united states","united kingdom","united arab emirates","china","india","germany","france","italy",
  "spain","portugal","netherlands","belgium","switzerland","austria","poland","sweden","norway","denmark",
  "finland","ireland","canada","mexico","brazil","argentina","chile","colombia","peru","australia",
  "new zealand","japan","south korea","north korea","singapore","malaysia","thailand","vietnam","indonesia",
  "philippines","pakistan","bangladesh","sri lanka","nepal","south africa","nigeria","kenya","egypt",
  "morocco","turkey","greece","russia","ukraine","romania","hungary","czech republic","slovakia",
  "saudi arabia","qatar","kuwait","bahrain","oman","israel","jordan","lebanon","iran","iraq","afghanistan",
];

export function extractCountry(input?: string | null): string | null {
  if (!input) return null;
  const lower = input.toLowerCase();
  // Nominatim display_name puts country last (comma-separated)
  const parts = lower.split(",").map((p) => p.trim()).filter(Boolean);
  const candidates = [parts[parts.length - 1], lower];
  for (const c of candidates) {
    if (!c) continue;
    if (COUNTRY_ALIASES[c]) return COUNTRY_ALIASES[c];
    if (KNOWN_COUNTRIES.includes(c)) return c;
  }
  for (const country of KNOWN_COUNTRIES) {
    if (lower.includes(country)) return country;
  }
  for (const [alias, full] of Object.entries(COUNTRY_ALIASES)) {
    const re = new RegExp(`(^|[^a-z])${alias.replace(/\./g, "\\.")}([^a-z]|$)`, "i");
    if (re.test(lower)) return full;
  }
  return null;
}

export function countriesConflict(a?: string | null, b?: string | null): boolean {
  const ca = extractCountry(a);
  const cb = extractCountry(b);
  if (!ca || !cb) return false;
  return ca !== cb;
}
