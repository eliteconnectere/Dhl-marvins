import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, lazy, Suspense, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Package, Calendar, ArrowLeft, CheckCircle2, Truck, Download } from "lucide-react";
import { format } from "date-fns";
import { DeliveryTimeline } from "@/components/DeliveryTimeline";
import { downloadReceipt } from "@/lib/receipt";
import { getPublicShipment } from "@/lib/tracking.functions";
import { toast } from "sonner";

const TrackingMap = lazy(() => import("@/components/TrackingMap"));

export const Route = createFileRoute("/track/$tn")({
  head: ({ params }) => ({
    meta: [
      { title: `Tracking ${params.tn} — DHL Delivery Service` },
      { name: "description", content: `Live tracking for shipment ${params.tn}.` },
    ],
  }),
  component: TrackPage,
});

interface Event {
  id: string;
  status: string;
  location_name: string | null;
  lat: number | null;
  lng: number | null;
  notes: string | null;
  created_at: string;
}

interface Shipment {
  id: string;
  tracking_number: string;
  status: string;
  sender_name: string | null;
  recipient_name: string | null;
  recipient_address: string | null;
  origin: string | null;
  destination: string | null;
  package_description: string | null;
  weight_kg: number | null;
  current_location_name: string | null;
  current_lat: number | null;
  current_lng: number | null;
  estimated_delivery: string | null;
  created_at: string;
  updated_at: string;
  route_from_lat: number | null;
  route_from_lng: number | null;
  route_to_lat: number | null;
  route_to_lng: number | null;
  route_to_name: string | null;
  route_duration_seconds: number | null;
  route_started_at: string | null;
  route_elapsed_seconds: number | null;
  route_paused: boolean | null;
  route_completed: boolean | null;
  animation_smoothness?: "fluid" | "standard" | "instant" | null;
  animation_easing?: "linear" | "ease-in-out" | "ease-out" | null;
  route_history?: {
    from_lat: number;
    from_lng: number;
    from_name?: string | null;
    to_lat: number;
    to_lng: number;
    to_name?: string | null;
  }[] | null;
  events: Event[];
}

function TrackPage() {
  const { tn } = Route.useParams();
  const navigate = useNavigate();
  const [input, setInput] = useState(tn);

  const qc = useQueryClient();
  const { data, isLoading, isError } = useQuery({
    queryKey: ["track", tn],
    queryFn: async () => {
      return (await getPublicShipment({ data: { tracking: tn } })) as Shipment | null;
    },
    refetchInterval: 30000,
  });

  // Realtime: refetch when this shipment or its events change
  useEffect(() => {
    if (!data?.id) return;
    const channel = supabase
      .channel(`track-${data.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "shipments", filter: `id=eq.${data.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["track", tn] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "tracking_events", filter: `shipment_id=eq.${data.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["track", tn] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [data?.id, qc, tn]);

  // Notify when the auto-route completes
  const prevCompletedRef = useRef<boolean | null>(null);
  useEffect(() => {
    const done = !!data?.route_completed;
    if (prevCompletedRef.current === false && done) {
      toast.success(
        `Your package has arrived at ${data?.route_to_name ?? data?.current_location_name ?? "its destination"}.`,
        { duration: 10000 },
      );
    }
    prevCompletedRef.current = done;
  }, [data?.route_completed, data?.route_to_name, data?.current_location_name]);

  const isDelivered = data?.status === "Delivered" || data?.status === "Completed";

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-6xl px-5 py-6 flex items-center justify-between">
        <Brand />
        <Link to="/" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-primary inline-flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Home
        </Link>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-16">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const v = input.trim().toUpperCase();
            if (v) navigate({ to: "/track/$tn", params: { tn: v } });
          }}
          className="flex gap-2 mb-8"
        >
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="h-12 bg-card tracking-wider font-mono"
          />
          <Button type="submit" className="h-12 bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
            <Search className="h-4 w-4" />
          </Button>
        </form>

        {isLoading && <div className="text-muted-foreground">Loading shipment…</div>}

        {!isLoading && (!data || isError) && (
          <div className="rounded-2xl border border-border bg-card p-10 text-center">
            <Package className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <h2 className="text-xl font-bold">Tracking number not found</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Please check the number <span className="font-mono">{tn}</span> and try again.
            </p>
          </div>
        )}

        {data && (
          <div className="grid lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-6">
              <div className="rounded-2xl border border-border bg-card p-6">
                <div className="text-xs uppercase tracking-widest text-muted-foreground">Tracking Number</div>
                <div className="font-mono text-2xl font-bold mt-1">{data.tracking_number}</div>
                <div className="mt-4 flex items-center gap-2">
                  <Badge
                    className={
                      isDelivered
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                        : "bg-primary/20 text-primary border-primary/30"
                    }
                  >
                    {isDelivered ? <CheckCircle2 className="h-3 w-3 mr-1" /> : <Truck className="h-3 w-3 mr-1" />}
                    {data.status}
                  </Badge>
                </div>

                <dl className="mt-6 space-y-3 text-sm">
                  {data.current_location_name && (
                    <Row label="Current Location" value={data.current_location_name} icon={MapPin} />
                  )}
                  <Row label="Last Updated" value={format(new Date(data.updated_at), "PPpp")} icon={Calendar} />
                  {data.origin && <Row label="Origin" value={data.origin} />}
                  {data.destination && <Row label="Destination" value={data.destination} />}
                  {data.recipient_name && <Row label="Recipient" value={data.recipient_name} />}
                  {data.recipient_address && <Row label="Address" value={data.recipient_address} />}
                  {data.package_description && <Row label="Package" value={data.package_description} />}
                  {data.weight_kg && <Row label="Weight" value={`${data.weight_kg} kg`} />}
                  {data.estimated_delivery && (
                    <Row
                      label="Estimated Delivery"
                      value={format(new Date(data.estimated_delivery), "PPP")}
                      icon={Calendar}
                    />
                  )}
                </dl>

                <Button
                  onClick={() => {
                    try {
                      downloadReceipt(data);
                      toast.success("Receipt downloaded");
                    } catch {
                      toast.error("Could not generate receipt");
                    }
                  }}
                  className="mt-6 w-full bg-primary text-primary-foreground hover:bg-primary/90 font-bold"
                >
                  <Download className="h-4 w-4 mr-2" /> Download Receipt (PDF)
                </Button>
              </div>

              <DeliveryTimeline
                status={data.status}
                createdAt={data.created_at}
                estimatedDelivery={data.estimated_delivery}
              />
            </div>

            <div className="lg:col-span-7 space-y-6">
              <div className="rounded-2xl border border-border bg-card p-2 overflow-hidden">
                {data.current_lat != null && data.current_lng != null ? (
                  <Suspense fallback={<div className="h-[360px] flex items-center justify-center text-muted-foreground">Loading map…</div>}>
                    <TrackingMap
                      lat={data.current_lat}
                      lng={data.current_lng}
                      label={data.current_location_name ?? data.tracking_number}
                      smoothness={data.animation_smoothness ?? "fluid"}
                      easing={data.animation_easing ?? "linear"}
                      history={data.route_history ?? null}
                      route={
                        data.route_from_lat != null && data.route_to_lat != null && data.route_duration_seconds
                          ? {
                              fromLat: data.route_from_lat,
                              fromLng: data.route_from_lng!,
                              toLat: data.route_to_lat,
                              toLng: data.route_to_lng!,
                              startedAt: data.route_started_at,
                              elapsedSeconds: data.route_elapsed_seconds ?? 0,
                              durationSeconds: data.route_duration_seconds,
                              paused: !!data.route_paused,
                              completed: !!data.route_completed,
                            }
                          : null
                      }
                    />
                  </Suspense>
                ) : data.current_location_name ? (
                  <Suspense fallback={<div className="h-[360px] flex items-center justify-center text-muted-foreground">Loading map…</div>}>
                    <TrackingMap label={data.current_location_name} />
                  </Suspense>
                ) : (
                  <div className="h-[360px] flex items-center justify-center text-muted-foreground text-sm">
                    Map location not yet set.
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-border bg-card p-6">
                <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-1 mb-4">
                  <h3 className="font-bold text-lg">Full Location & Status History</h3>
                  <div className="text-xs text-muted-foreground">
                    Last updated {format(new Date(data.updated_at), "PPpp")}
                  </div>
                </div>
                <div className="space-y-4">
                  {data.events.map((e, i) => (
                    <div key={e.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`h-3 w-3 rounded-full ${i === 0 ? "bg-primary ring-4 ring-primary/20" : "bg-muted-foreground/40"}`} />
                        {i < data.events.length - 1 && <div className="w-px flex-1 bg-border" />}
                      </div>
                      <div className="pb-4 flex-1">
                        <div className={`text-sm font-semibold ${i === 0 ? "text-primary" : ""}`}>{e.status}</div>
                        {e.location_name && (
                          <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                            <MapPin className="h-3 w-3" /> {e.location_name}
                          </div>
                        )}
                        <div className="text-xs text-muted-foreground mt-0.5">
                          Last updated: {format(new Date(e.created_at), "PPpp")}
                        </div>
                        {e.notes && <div className="text-xs text-muted-foreground mt-1 italic">{e.notes}</div>}
                      </div>
                    </div>
                  ))}
                  {data.events.length === 0 && (
                    <div className="text-sm text-muted-foreground">No updates yet.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Row({ label, value, icon: Icon }: { label: string; value: string; icon?: React.ComponentType<{ className?: string }> }) {
  return (
    <div className="flex gap-3">
      <dt className="w-32 shrink-0 text-xs uppercase tracking-wider text-muted-foreground pt-0.5">{label}</dt>
      <dd className="flex-1 text-foreground flex items-start gap-1">
        {Icon && <Icon className="h-4 w-4 text-primary mt-0.5 shrink-0" />}
        <span>{value}</span>
      </dd>
    </div>
  );
}
