import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";

const ADMIN_EMAILS = new Set([
  "peterssonbillie@gmail.com",
  "agentneeraj57@gmail.com",
  "thebloodline.black@gmail.com",
]);

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Admin Login — DHL Delivery Service" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin" });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (!ADMIN_EMAILS.has(normalizedEmail)) {
      toast.error("This email is not approved for admin access.");
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: normalizedEmail, password });
      if (error) throw error;
      navigate({ to: "/admin" });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Authentication failed";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <header className="mx-auto max-w-6xl px-5 py-6 flex items-center justify-between">
        <Brand />
        <Link to="/" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-primary inline-flex items-center gap-1">
          <ArrowLeft className="h-3 w-3" /> Home
        </Link>
      </header>

      <main className="mx-auto max-w-md px-5 pt-16">
        <div className="rounded-2xl border border-border bg-card p-8 shadow-2xl shadow-black/40">
          <h1 className="text-2xl font-black tracking-tight">
            Administrator Login
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Only the designated administrator account has access.
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 bg-background" placeholder="Approved admin email only" />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 bg-background" />
            </div>
            <Button type="submit" disabled={loading} className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
              {loading ? "Please wait…" : "Sign in"}
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
