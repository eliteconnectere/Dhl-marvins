import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

import { getShipmentRoute, type RouteMode } from "@/lib/route.functions";

export type Smoothness = "fluid" | "standard" | "instant";
export type Easing = "linear" | "ease-in-out" | "ease-out";

export interface RouteLeg {
  from_lat: number;
  from_lng: number;
  from_name?: string | null;
  to_lat: number;
  to_lng: number;
  to_name?: string | null;
}

interface Props {
  lat?: number | null;
  lng?: number | null;
  label?: string;
  height?: number;
  smoothness?: Smoothness;
  easing?: Easing;
  debug?: boolean;
  /** Completed legs travelled before the current (rerouted) leg. */
  history?: RouteLeg[] | null;
  route?: {
    fromLat: number;
    fromLng: number;
    toLat: number;
    toLng: number;
    startedAt: string | null;
    elapsedSeconds: number;
    durationSeconds: number;
    paused: boolean;
    completed: boolean;
  } | null;
}


interface Pt {
  lat: number;
  lng: number;
}

// ---------------------------------------------------------------------------
// Google Maps JS API loader (single shared script tag)
// ---------------------------------------------------------------------------
let mapsPromise: Promise<any> | null = null;

function loadGoogleMaps(): Promise<any> {
  if (typeof window === "undefined") return Promise.reject(new Error("no window"));
  const w = window as any;
  if (w.google?.maps?.OverlayView) return Promise.resolve(w.google.maps);
  if (mapsPromise) return mapsPromise;

  mapsPromise = new Promise((resolve, reject) => {
    const key = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_BROWSER_KEY as string | undefined;
    const channel = import.meta.env.VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_TRACKING_ID as string | undefined;
    if (!key) {
      reject(new Error("Google Maps browser key missing"));
      return;
    }
    w.__dhlMapsReady = () => resolve(w.google.maps);
    const script = document.createElement("script");
    script.src =
      `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}` +
      `&libraries=geometry&loading=async&callback=__dhlMapsReady` +
      (channel ? `&channel=${encodeURIComponent(channel)}` : "");
    script.async = true;
    script.onerror = () => reject(new Error("Failed to load Google Maps"));
    document.head.appendChild(script);
  });
  return mapsPromise;
}

// HTML overlay anchored to real geographic coordinates — repositions itself on
// every zoom / pan / resize because Maps calls draw() with a fresh projection.
function makeOverlayClass(maps: any) {
  return class HtmlOverlay extends maps.OverlayView {
    el: HTMLElement;
    pos: any;
    constructor(el: HTMLElement, pos: any) {
      super();
      this.el = el;
      this.pos = pos;
    }
    onAdd() {
      this.el.style.position = "absolute";
      // Panes are unavailable if the Maps API failed to authorize/initialize.
      this.getPanes()?.floatPane?.appendChild(this.el);
    }
    onRemove() {
      if (this.el.parentNode) this.el.parentNode.removeChild(this.el);
    }

    setPosition(pos: any) {
      this.pos = pos;
      this.draw();
    }
    draw() {
      const projection = this.getProjection();
      if (!projection || !this.pos) return;
      const p = projection.fromLatLngToDivPixel(this.pos);
      if (!p) return;
      this.el.style.left = `${p.x}px`;
      this.el.style.top = `${p.y}px`;
    }
  };
}

function preset(s: Smoothness) {
  switch (s) {
    case "instant":
      return { correctionCap: 1.0, completionEaseMs: 0 };
    case "standard":
      return { correctionCap: 0.15, completionEaseMs: 300 };
    case "fluid":
    default:
      return { correctionCap: 0.05, completionEaseMs: 600 };
  }
}

function applyEasing(p: number, e: Easing): number {
  const x = Math.min(1, Math.max(0, p));
  switch (e) {
    case "ease-in-out":
      return 0.5 - Math.cos(Math.PI * x) / 2;
    case "ease-out":
      return 1 - Math.pow(1 - x, 3);
    case "linear":
    default:
      return x;
  }
}

// Rough planar distance — only used for relative interpolation weights.
function segLen(a: Pt, b: Pt) {
  const dy = b.lat - a.lat;
  const dx = (b.lng - a.lng) * Math.cos(((a.lat + b.lat) / 2) * (Math.PI / 180));
  return Math.sqrt(dx * dx + dy * dy);
}

function buildCumulative(points: Pt[]) {
  const cum = [0];
  for (let i = 1; i < points.length; i++) cum.push(cum[i - 1] + segLen(points[i - 1], points[i]));
  return cum;
}

const LIVE_MARKER_STYLES = `
@keyframes dhl-ripple {
  0%   { transform: scale(0.6); opacity: 0.55; }
  80%  { transform: scale(2.2); opacity: 0; }
  100% { transform: scale(2.2); opacity: 0; }
}
@keyframes dhl-glow {
  0%,100% { opacity: 0.55; }
  50%     { opacity: 0.9; }
}
@keyframes dhl-bounce {
  0%, 70%, 100% { transform: translateY(0); }
  80%           { transform: translateY(-6px); }
  90%           { transform: translateY(-2px); }
}
`;

export default function TrackingMap({
  lat,
  lng,
  label,
  height = 360,
  route,
  history,
  smoothness = "fluid",
  easing = "linear",
  debug = false,
}: Props) {
  const mapDivRef = useRef<HTMLDivElement | null>(null);
  const [maps, setMaps] = useState<any>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const isRoute =
    !!route &&
    route.durationSeconds > 0 &&
    Number.isFinite(route.fromLat) &&
    Number.isFinite(route.toLat);

  const fromLat = isRoute ? route!.fromLat : 0;
  const fromLng = isRoute ? route!.fromLng : 0;
  const toLat = isRoute ? route!.toLat : 0;
  const toLng = isRoute ? route!.toLng : 0;

  // --- load the JS API -------------------------------------------------
  useEffect(() => {
    let alive = true;
    loadGoogleMaps()
      .then((m) => alive && setMaps(m))
      .catch((e) => alive && setLoadError(e?.message ?? "Map failed to load"));
    return () => {
      alive = false;
    };
  }, []);

  // --- resolve the real path (road vs flight) --------------------------
  const [path, setPath] = useState<{ mode: RouteMode; points: Pt[] } | null>(null);

  useEffect(() => {
    if (!isRoute) {
      setPath(null);
      return;
    }
    let alive = true;
    setPath(null);
    getShipmentRoute({ data: { fromLat, fromLng, toLat, toLng } })
      .then((res) => {
        if (!alive) return;
        setPath({ mode: res.mode, points: res.mode === "road" ? res.points : [] });
      })
      .catch(() => alive && setPath({ mode: "flight", points: [] }));
    return () => {
      alive = false;
    };
  }, [isRoute, fromLat, fromLng, toLat, toLng]);

  // Geodesic arc fallback for flight routes (smooth curve, real coordinates).
  const resolvedPoints = useMemo<Pt[]>(() => {
    if (!isRoute || !maps) return [];
    if (path?.mode === "road" && path.points.length > 1) return path.points;
    if (!path) return [];
    const spherical = maps.geometry?.spherical;
    const a = new maps.LatLng(fromLat, fromLng);
    const b = new maps.LatLng(toLat, toLng);
    if (!spherical?.interpolate) return [{ lat: fromLat, lng: fromLng }, { lat: toLat, lng: toLng }];
    const steps = 128;
    const out: Pt[] = [];
    for (let i = 0; i <= steps; i++) {
      const p = spherical.interpolate(a, b, i / steps);
      out.push({ lat: p.lat(), lng: p.lng() });
    }
    return out;
  }, [isRoute, maps, path, fromLat, fromLng, toLat, toLng]);

  const isFlight = !!path && path.mode === "flight";

  // --- map instance ----------------------------------------------------
  const mapRef = useRef<any>(null);
  const traveledLineRef = useRef<any>(null);
  const remainingLineRef = useRef<any>(null);
  const flowLineRef = useRef<any>(null);
  const liveOverlayRef = useRef<any>(null);
  const destOverlayRef = useRef<any>(null);
  const staticMarkerRef = useRef<any>(null);
  const historyLinesRef = useRef<any[]>([]);
  const originOverlayRef = useRef<any>(null);

  // Overlay hosts are plain DOM nodes created outside React. Google Maps moves
  // them into (and out of) its own panes; React must never own their placement
  // or the next commit throws "insertBefore ... not a child of this node".
  // Marker markup is portalled INTO these hosts, so React still manages content.
  const [hosts] = useState(() =>
    typeof document === "undefined"
      ? null
      : {
          origin: document.createElement("div"),
          dest: document.createElement("div"),
          live: document.createElement("div"),
        },
  );


  // Completed legs travelled before the current one (kept visible after a reroute).
  const legs = useMemo<RouteLeg[]>(
    () =>
      (history ?? []).filter(
        (l) =>
          Number.isFinite(l?.from_lat) &&
          Number.isFinite(l?.from_lng) &&
          Number.isFinite(l?.to_lat) &&
          Number.isFinite(l?.to_lng),
      ),
    [history],
  );

  // Where the whole journey originally started.
  const origin = useMemo(() => {
    if (legs.length > 0) return { lat: legs[0].from_lat, lng: legs[0].from_lng, name: legs[0].from_name };
    if (isRoute) return { lat: route!.fromLat, lng: route!.fromLng, name: null as string | null };
    return null;
  }, [legs, isRoute, route]);



  useEffect(() => {
    if (!maps || !mapDivRef.current || mapRef.current) return;
    mapRef.current = new maps.Map(mapDivRef.current, {
      center: { lat: isRoute ? (fromLat + toLat) / 2 : (lat ?? 0), lng: isRoute ? (fromLng + toLng) / 2 : (lng ?? 0) },
      zoom: 5,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
      gestureHandling: "greedy",
      clickableIcons: false,
    });
  }, [maps, isRoute, fromLat, fromLng, toLat, toLng, lat, lng]);

  // Static (no-route) mode: single marker at the given coordinates.
  useEffect(() => {
    if (!maps || !mapRef.current || isRoute) return;
    const map = mapRef.current;
    if (typeof lat !== "number" || typeof lng !== "number") return;
    const pos = { lat, lng };
    if (!staticMarkerRef.current) {
      staticMarkerRef.current = new maps.Marker({ map, position: pos, title: label ?? "" });
    } else {
      staticMarkerRef.current.setPosition(pos);
    }
    map.setCenter(pos);
    map.setZoom(8);
  }, [maps, isRoute, lat, lng, label]);

  // Route mode: polylines + overlays, all anchored to real coordinates.
  useEffect(() => {
    if (!maps || !mapRef.current || !isRoute || resolvedPoints.length < 2) return;
    const map = mapRef.current;
    const Overlay = makeOverlayClass(maps);

    const stroke = isFlight
      ? {
          strokeOpacity: 0,
          icons: [
            {
              icon: { path: "M 0,-1 0,1", strokeOpacity: 1, strokeWeight: 4, scale: 1, strokeColor: "#FFCC00" },
              offset: "0",
              repeat: "14px",
            },
          ],
        }
      : { strokeOpacity: 0.95, strokeColor: "#FFCC00", strokeWeight: 5 };

    remainingLineRef.current = new maps.Polyline({
      map,
      path: resolvedPoints,
      geodesic: true,
      strokeColor: "#FFCC00",
      strokeWeight: 5,
      zIndex: 2,
      ...stroke,
    });
    traveledLineRef.current = new maps.Polyline({
      map,
      path: [resolvedPoints[0]],
      geodesic: true,
      strokeColor: "#FFCC00",
      strokeOpacity: 1,
      strokeWeight: 6,
      zIndex: 3,
    });
    // Continuous "flow" pulses travelling along the remaining route.
    flowLineRef.current = new maps.Polyline({
      map,
      path: resolvedPoints,
      geodesic: true,
      strokeOpacity: 0,
      zIndex: 4,
      icons: [
        {
          icon: {
            path: "M 0,-1 0,1",
            strokeColor: "#FFF6C2",
            strokeOpacity: 0.9,
            strokeWeight: 4,
            scale: 1,
          },
          offset: "0%",
          repeat: "22px",
        },
        // A single glider that runs the whole remaining route: an aircraft
        // arrow for flights, a bright pulse dot for road journeys.
        isFlight
          ? {
              icon: {
                path: maps.SymbolPath.FORWARD_CLOSED_ARROW,
                scale: 4,
                fillColor: "#FFFFFF",
                fillOpacity: 1,
                strokeColor: "#B30000",
                strokeWeight: 1.5,
              },
              offset: "0%",
            }
          : {
              icon: {
                path: maps.SymbolPath.CIRCLE,
                scale: 4,
                fillColor: "#FFFFFF",
                fillOpacity: 0.95,
                strokeColor: "#FFCC00",
                strokeWeight: 2,
              },
              offset: "0%",
            },
      ],
    });



    if (hosts) {
      destOverlayRef.current = new Overlay(hosts.dest, new maps.LatLng(toLat, toLng));
      destOverlayRef.current.setMap(map);

      liveOverlayRef.current = new Overlay(
        hosts.live,
        new maps.LatLng(resolvedPoints[0].lat, resolvedPoints[0].lng),
      );
      liveOverlayRef.current.setMap(map);
    }


    const bounds = new maps.LatLngBounds();
    resolvedPoints.forEach((p) => bounds.extend(p));
    legs.forEach((l) => {
      bounds.extend({ lat: l.from_lat, lng: l.from_lng });
      bounds.extend({ lat: l.to_lat, lng: l.to_lng });
    });
    map.fitBounds(bounds, 56);

    return () => {
      remainingLineRef.current?.setMap(null);
      traveledLineRef.current?.setMap(null);
      flowLineRef.current?.setMap(null);
      destOverlayRef.current?.setMap(null);
      liveOverlayRef.current?.setMap(null);
      remainingLineRef.current = null;
      traveledLineRef.current = null;
      flowLineRef.current = null;
      destOverlayRef.current = null;
      liveOverlayRef.current = null;
    };
  }, [maps, isRoute, isFlight, resolvedPoints, toLat, toLng, legs, hosts]);

  // Completed history legs: static grey trail + the original starting pin.
  useEffect(() => {
    if (!maps || !mapRef.current) return;
    const map = mapRef.current;
    const Overlay = makeOverlayClass(maps);

    historyLinesRef.current = legs.map(
      (l) =>
        new maps.Polyline({
          map,
          path: [
            { lat: l.from_lat, lng: l.from_lng },
            { lat: l.to_lat, lng: l.to_lng },
          ],
          geodesic: true,
          strokeColor: "#9ca3af",
          strokeOpacity: 0,
          zIndex: 1,
          icons: [
            {
              icon: {
                path: "M 0,-1 0,1",
                strokeColor: "#9ca3af",
                strokeOpacity: 0.9,
                strokeWeight: 4,
                scale: 1,
              },
              offset: "0",
              repeat: "12px",
            },
          ],
        }),
    );

    if (origin && hosts) {
      originOverlayRef.current = new Overlay(
        hosts.origin,

        new maps.LatLng(origin.lat, origin.lng),
      );
      originOverlayRef.current.setMap(map);
    }

    return () => {
      historyLinesRef.current.forEach((p) => p.setMap(null));
      historyLinesRef.current = [];
      originOverlayRef.current?.setMap(null);
      originOverlayRef.current = null;
    };
  }, [maps, legs, origin, hosts]);


  // --- animation loop (unchanged math) --------------------------------
  const progressBarRef = useRef<HTMLDivElement | null>(null);
  const progressLabelRef = useRef<HTMLSpanElement | null>(null);
  const diagRef = useRef<HTMLDivElement | null>(null);
  const displayedRef = useRef<number>(0);
  const speedMultRef = useRef<number>(1);

  const routeRef = useRef(route);
  useEffect(() => {
    routeRef.current = route;
  }, [route]);
  const smoothnessRef = useRef(smoothness);
  useEffect(() => {
    smoothnessRef.current = smoothness;
  }, [smoothness]);
  const easingRef = useRef(easing);
  useEffect(() => {
    easingRef.current = easing;
  }, [easing]);

  const pointsRef = useRef<Pt[]>([]);
  const cumRef = useRef<number[]>([]);
  useEffect(() => {
    pointsRef.current = resolvedPoints;
    cumRef.current = resolvedPoints.length > 1 ? buildCumulative(resolvedPoints) : [];
  }, [resolvedPoints]);

  useEffect(() => {
    if (!route || !route.durationSeconds) return;
    const nowMs = Date.now();
    const live =
      route.elapsedSeconds +
      (route.startedAt && !route.paused && !route.completed
        ? Math.max(0, (nowMs - new Date(route.startedAt).getTime()) / 1000)
        : 0);
    displayedRef.current = route.completed
      ? 1
      : Math.min(1, Math.max(0, live / route.durationSeconds));
  }, [route?.startedAt, route?.durationSeconds]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!isRoute || !maps) return;
    let rafId = 0;
    let lastT = performance.now();
    let frames = 0;
    let fpsWindowStart = lastT;
    let fps = 0;
    let lastLineUpdate = 0;

    const tick = (t: number) => {
      const dt = Math.max(0, Math.min(0.25, (t - lastT) / 1000));
      lastT = t;
      frames++;
      if (t - fpsWindowStart >= 1000) {
        fps = (frames * 1000) / (t - fpsWindowStart);
        frames = 0;
        fpsWindowStart = t;
      }

      const r = routeRef.current;
      const pts = pointsRef.current;
      const cum = cumRef.current;
      const easingMode = easingRef.current;
      const { correctionCap, completionEaseMs } = preset(smoothnessRef.current);

      if (!r || !r.durationSeconds || pts.length < 2) {
        rafId = requestAnimationFrame(tick);
        return;
      }

      const cur = displayedRef.current;
      let next = cur;
      let serverProgress = cur;

      if (r.completed) {
        if (completionEaseMs <= 0) {
          next = 1;
        } else {
          const step = (dt * 1000) / completionEaseMs;
          next = Math.min(1, cur + step * (1 - cur + 0.001));
        }
        serverProgress = 1;
        speedMultRef.current = 1;
      } else if (r.paused || !r.startedAt) {
        next = cur;
        speedMultRef.current = 0;
      } else {
        const nominalSpeed = 1 / r.durationSeconds;
        const serverLive =
          r.elapsedSeconds + Math.max(0, (Date.now() - new Date(r.startedAt).getTime()) / 1000);
        serverProgress = Math.min(1, Math.max(0, serverLive / r.durationSeconds));

        const drift = serverProgress - cur;
        const desiredExtra = drift / Math.max(2, r.durationSeconds * 0.02);
        const clampedExtra = Math.max(-correctionCap, Math.min(correctionCap, desiredExtra));
        const speed = nominalSpeed * (1 + clampedExtra);
        speedMultRef.current = 1 + clampedExtra;

        next = Math.min(1, Math.max(0, cur + speed * dt));
      }

      displayedRef.current = next;
      const eased = applyEasing(next, easingMode);

      // Position along the real path by travelled distance.
      const total = cum[cum.length - 1] || 1;
      const target = eased * total;
      let i = 1;
      while (i < cum.length - 1 && cum[i] < target) i++;
      const segStart = cum[i - 1];
      const segEnd = cum[i];
      const f = segEnd > segStart ? (target - segStart) / (segEnd - segStart) : 0;
      const a = pts[i - 1];
      const b = pts[i];
      const curLat = a.lat + (b.lat - a.lat) * f;
      const curLng = a.lng + (b.lng - a.lng) * f;

      if (liveOverlayRef.current && maps) {
        liveOverlayRef.current.setPosition(new maps.LatLng(curLat, curLng));
      }

      // Polylines are geographic — refresh a few times per second only.
      if (t - lastLineUpdate > 120) {
        lastLineUpdate = t;
        const head = pts.slice(0, i);
        head.push({ lat: curLat, lng: curLng });
        // Guarded: if the Maps API instance is unavailable (key/referrer error,
        // map torn down mid-frame) its internals can throw — that must never
        // bubble out of the animation frame.
        try {
          traveledLineRef.current?.setPath(head);
          const tail: Pt[] = [{ lat: curLat, lng: curLng }, ...pts.slice(i)];
          remainingLineRef.current?.setPath(tail);

          const flow = flowLineRef.current;
          if (flow) {
            const active = !r.completed && !r.paused && !!r.startedAt;
            flow.setPath(active ? tail : []);
            if (active) {
              const icons = flow.get("icons");
              if (icons?.[0]) {
                icons[0].offset = `${((t / 900) * 100) % 100}%`;
                if (icons[1]) icons[1].offset = `${((t / 6000) * 100) % 100}%`;
                flow.set("icons", icons);
              }
            }
          }
        } catch {
          /* map not ready — skip this frame */
        }

      }


      if (progressBarRef.current) progressBarRef.current.style.width = `${eased * 100}%`;
      if (progressLabelRef.current) {
        progressLabelRef.current.textContent = r.completed
          ? "· ✓ arrived"
          : r.paused
            ? "· paused"
            : `· en route ${Math.round(eased * 100)}%`;
      }

      if (debug && diagRef.current) {
        const drift = (serverProgress - next) * 100;
        diagRef.current.textContent =
          `fps ${fps.toFixed(0)}` +
          ` · local ${(next * 100).toFixed(1)}%` +
          ` · server ${(serverProgress * 100).toFixed(1)}%` +
          ` · drift ${drift >= 0 ? "+" : ""}${drift.toFixed(2)}%` +
          ` · ×${speedMultRef.current.toFixed(3)}` +
          ` · ${smoothnessRef.current}/${easingMode}` +
          ` · ${isFlight ? "flight" : "road"}` +
          (r.paused ? " · paused" : "") +
          (r.completed ? " · done" : "");
      }

      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isRoute, debug, maps, isFlight]);

  const openHref = useMemo(() => {
    if (isRoute && route) {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${route.fromLat},${route.fromLng}`)}`;
    }
    const q = encodeURIComponent(
      typeof lat === "number" && typeof lng === "number" ? `${lat},${lng}` : (label ?? ""),
    );
    return `https://www.google.com/maps/search/?api=1&query=${q}`;
  }, [isRoute, route, lat, lng, label]);

  return (
    <div style={{ borderRadius: 12, overflow: "hidden", position: "relative", height }}>
      <style>{LIVE_MARKER_STYLES}</style>

      <div ref={mapDivRef} style={{ width: "100%", height, background: "#e5e3df" }} />

      {isRoute && path && (
        <div
          style={{
            position: "absolute",
            top: 10,
            left: 10,
            zIndex: 5,
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            padding: "5px 10px",
            borderRadius: 999,
            fontSize: 11,
            fontWeight: 800,
            letterSpacing: "0.04em",
            background: "rgba(0,0,0,0.72)",
            color: "#FFCC00",
            border: "1px solid rgba(255,204,0,0.4)",
            backdropFilter: "blur(4px)",
            pointerEvents: "none",
          }}
        >
          {isFlight ? "✈️ FLIGHT ROUTE" : "🚚 ROAD ROUTE"}
        </div>
      )}


      {loadError && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
            textAlign: "center",
            fontSize: 12,
            fontWeight: 700,
            background: "rgba(0,0,0,0.7)",
            color: "#fff",
          }}
        >
          Map unavailable: {loadError}
        </div>
      )}

      {/* --- Original starting point overlay (static, grey) --- */}
      {hosts && createPortal(
      <div

        style={{
          position: "absolute",
          transform: "translate(-50%, -100%)",
          pointerEvents: "none",
          display: origin ? "block" : "none",
          whiteSpace: "nowrap",
        }}
      >
        <svg viewBox="0 0 24 30" width="20" height="25" style={{ filter: "drop-shadow(0 3px 5px rgba(0,0,0,0.45))", display: "block" }}>
          <path
            d="M12 0C5.4 0 0 5.4 0 12c0 8.6 12 18 12 18s12-9.4 12-18C24 5.4 18.6 0 12 0z"
            fill="#9ca3af"
            stroke="#000"
            strokeWidth="1.25"
          />
          <circle cx="12" cy="12" r="4.5" fill="#3f3f46" />
        </svg>
        <div
          style={{
            position: "absolute",
            left: 24,
            top: -2,
            padding: "3px 7px",
            fontSize: 10,
            fontWeight: 700,
            background: "rgba(75,85,99,0.95)",
            color: "#fff",
            borderRadius: 6,
            boxShadow: "0 4px 10px rgba(0,0,0,0.3)",
            letterSpacing: ".02em",
          }}
        >
          📦 Origin
        </div>
      </div>, hosts.origin)}

      {/* --- Destination overlay (static, green) --- */}

      {hosts && createPortal(
      <div

        style={{
          position: "absolute",
          transform: "translate(-50%, -100%)",
          pointerEvents: "none",
          display: isRoute ? "block" : "none",
          whiteSpace: "nowrap",
        }}
      >
        <svg viewBox="0 0 24 30" width="24" height="30" style={{ filter: "drop-shadow(0 3px 5px rgba(0,0,0,0.5))", display: "block" }}>
          <path
            d="M12 0C5.4 0 0 5.4 0 12c0 8.6 12 18 12 18s12-9.4 12-18C24 5.4 18.6 0 12 0z"
            fill="#22c55e"
            stroke="#000"
            strokeWidth="1.25"
          />
          <circle cx="12" cy="12" r="4.5" fill="#0f5132" />
        </svg>
        <div
          style={{
            position: "absolute",
            left: 28,
            top: -2,
            padding: "4px 8px",
            fontSize: 10.5,
            fontWeight: 700,
            background: "rgba(34,197,94,0.95)",
            color: "#fff",
            borderRadius: 6,
            boxShadow: "0 4px 10px rgba(0,0,0,0.3)",
            letterSpacing: ".02em",
          }}
        >
          🏁 Destination
        </div>
      </div>, hosts.dest)}

      {/* --- Live package overlay (animated, red) --- */}
      {hosts && createPortal(
      <div

        style={{
          position: "absolute",
          transform: "translate(-50%, -100%)",
          pointerEvents: "none",
          display: isRoute ? "block" : "none",
          width: 36,
          height: 42,
        }}
      >
        <div
          style={{
            position: "absolute",
            left: 18,
            top: 32,
            width: 20,
            height: 20,
            marginLeft: -10,
            marginTop: -10,
            borderRadius: "50%",
            background: "rgba(212,5,17,0.45)",
            animation: "dhl-ripple 1.8s ease-out infinite",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 18,
            top: 32,
            width: 20,
            height: 20,
            marginLeft: -10,
            marginTop: -10,
            borderRadius: "50%",
            background: "rgba(212,5,17,0.35)",
            animation: "dhl-ripple 1.8s ease-out 0.9s infinite",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 18,
            top: 32,
            width: 26,
            height: 26,
            marginLeft: -13,
            marginTop: -13,
            borderRadius: "50%",
            boxShadow: "0 0 0 2px rgba(212,5,17,0.35), 0 0 14px 4px rgba(212,5,17,0.55)",
            animation: "dhl-glow 2s ease-in-out infinite",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: 36,
            height: 42,
            animation: "dhl-bounce 2.5s ease-in-out infinite",
            filter: "drop-shadow(0 5px 7px rgba(0,0,0,0.5))",
          }}
        >
          <svg viewBox="0 0 28 32" width="36" height="42">
            <path
              d="M14 0C6.3 0 0 6.3 0 14c0 10 14 18 14 18s14-8 14-18C28 6.3 21.7 0 14 0z"
              fill="#D40511"
              stroke="#000"
              strokeWidth="1"
            />
            <circle cx="14" cy="14" r="5.5" fill="#7a0308" />
          </svg>
        </div>
        <div
          style={{
            position: "absolute",
            left: 42,
            top: 4,
            padding: "4px 8px",
            fontSize: 10.5,
            fontWeight: 700,
            background: "rgba(212,5,17,0.95)",
            color: "#fff",
            borderRadius: 6,
            boxShadow: "0 4px 10px rgba(0,0,0,0.35)",
            whiteSpace: "nowrap",
            letterSpacing: ".02em",
          }}
        >
          🚚 Live Package
        </div>
      </div>, hosts.live)}


      {label && (
        <div
          style={{
            position: "absolute",
            left: 12,
            top: 12,
            maxWidth: "calc(100% - 24px)",
            padding: "7px 10px",
            fontSize: 12,
            fontWeight: 700,
            background: "rgba(0,0,0,0.78)",
            color: "#fff",
            borderRadius: 8,
            boxShadow: "0 8px 22px rgba(0,0,0,0.22)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            zIndex: 5,
          }}
        >
          📍 {label}
          {isRoute && (
            <span ref={progressLabelRef} style={{ marginLeft: 8, opacity: 0.85 }}>
              · en route 0%
            </span>
          )}
        </div>
      )}

      {isRoute && (
        <div
          style={{
            position: "absolute",
            left: 12,
            top: label ? 48 : 12,
            padding: "4px 8px",
            fontSize: 10,
            fontWeight: 700,
            background: "rgba(0,0,0,0.72)",
            color: "#FFCC00",
            borderRadius: 6,
            letterSpacing: ".04em",
            zIndex: 5,
          }}
        >
          {path === null ? "RESOLVING ROUTE…" : isFlight ? "✈️ FLIGHT ROUTE" : "🛣️ ROAD ROUTE"}
        </div>
      )}

      {isRoute && !route?.completed && (
        <div
          style={{
            position: "absolute",
            left: 12,
            right: 12,
            bottom: 44,
            height: 6,
            borderRadius: 999,
            background: "rgba(255,255,255,0.25)",
            overflow: "hidden",
            zIndex: 5,
          }}
        >
          <div
            ref={progressBarRef}
            style={{
              width: "0%",
              height: "100%",
              background: "linear-gradient(90deg,#FFCC00,#D40511)",
              willChange: "width",
            }}
          />
        </div>
      )}

      {debug && isRoute && (
        <div
          ref={diagRef}
          style={{
            position: "absolute",
            right: 12,
            top: 12,
            padding: "6px 8px",
            fontSize: 10,
            fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
            fontWeight: 600,
            background: "rgba(0,0,0,0.78)",
            color: "#FFCC00",
            borderRadius: 6,
            letterSpacing: ".02em",
            maxWidth: "70%",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            zIndex: 5,
          }}
        >
          diagnostics…
        </div>
      )}

      <a
        href={openHref}
        target="_blank"
        rel="noreferrer"
        style={{
          position: "absolute",
          right: 12,
          bottom: 12,
          padding: "6px 10px",
          fontSize: 11,
          fontWeight: 700,
          background: "rgba(0,0,0,0.75)",
          color: "#fff",
          borderRadius: 8,
          textDecoration: "none",
          letterSpacing: ".05em",
          zIndex: 5,
        }}
      >
        OPEN IN GOOGLE MAPS
      </a>
    </div>
  );
}
