import { Link } from "@tanstack/react-router";
import { Package } from "lucide-react";

export function Brand({ subtitle }: { subtitle?: string }) {
  return (
    <Link to="/" className="inline-flex items-center gap-3 group">
      <div className="flex items-center justify-center h-10 w-10 rounded-md bg-primary text-primary-foreground shadow-lg shadow-primary/20">
        <Package className="h-5 w-5" strokeWidth={2.5} />
      </div>
      <div className="leading-tight">
        <div className="font-black tracking-tight text-lg">
          <span className="text-primary">DHL</span>
          <span className="text-accent ml-1">Delivery</span>
        </div>
        <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          {subtitle ?? "Shipment Tracking"}
        </div>
      </div>
    </Link>
  );
}
