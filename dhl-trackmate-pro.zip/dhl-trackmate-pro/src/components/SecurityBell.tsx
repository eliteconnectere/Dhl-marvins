import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface Alert {
  id: string; created_at: string; kind: string;
  device_type: string | null; os: string | null; browser: string | null;
  country: string | null; region: string | null; city: string | null;
  timezone: string | null; language: string | null; screen: string | null; page: string | null;
  read_at: string | null;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const table = () => (supabase as any).from("security_alerts");
const u = (v: string | null) => v || "Unknown";

export function SecurityBell() {
  const qc = useQueryClient();
  const { data: alerts = [] } = useQuery({
    queryKey: ["security-alerts"],
    queryFn: async () => {
      const { data, error } = await table().select("*").order("created_at", { ascending: false }).limit(100);
      if (error) throw error;
      return data as Alert[];
    },
    refetchInterval: 30000,
  });
  const unread = alerts.filter((a) => !a.read_at).length;
  const markRead = async (ids: string[]) => {
    if (!ids.length) return;
    await table().update({ read_at: new Date().toISOString() }).in("id", ids);
    qc.invalidateQueries({ queryKey: ["security-alerts"] });
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative" aria-label="Security alerts">
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
              {unread > 99 ? "99+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="font-bold text-sm">Security alerts</div>
          {unread > 0 && (
            <button className="text-xs text-primary hover:underline" onClick={() => markRead(alerts.filter((a) => !a.read_at).map((a) => a.id))}>
              Mark all read
            </button>
          )}
        </div>
        <div className="max-h-96 overflow-auto divide-y divide-border">
          {alerts.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">No alerts yet.</div>
          ) : alerts.map((a) => (
            <div key={a.id} className={`px-4 py-3 text-xs space-y-0.5 ${a.read_at ? "opacity-60" : "bg-secondary/40"}`}>
              <div className="font-semibold text-sm">🔔 New Security Alert</div>
              <div>{a.kind === "new_region" ? "Known device from a new region" : "New/unrecognized device detected"}</div>
              <div>Device: {u(a.device_type)}{a.os && a.os !== "Unknown" ? ` · ${a.os}` : ""}{a.browser && a.browser !== "Unknown" ? ` · ${a.browser}` : ""}</div>
              <div>Region: {a.country ? [a.city, a.region, a.country].filter(Boolean).join(", ") : "Unknown"}</div>
              <div>Time: {format(new Date(a.created_at), "d MMM yyyy, HH:mm")}</div>
              <div className="text-muted-foreground">
                Timezone: {u(a.timezone)} · Language: {u(a.language)} · Screen: {u(a.screen)}
                {a.page ? ` · Page: ${a.page}` : ""}
              </div>
              {!a.read_at && (
                <button className="text-primary hover:underline" onClick={() => markRead([a.id])}>Mark as read</button>
              )}
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
