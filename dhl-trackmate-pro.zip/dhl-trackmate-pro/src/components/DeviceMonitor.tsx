import { useEffect } from "react";
import { useLocation } from "@tanstack/react-router";
import { reportDeviceVisit } from "@/lib/device-monitor.functions";

function detect() {
  const ua = navigator.userAgent;
  const touchMac = /Macintosh/.test(ua) && navigator.maxTouchPoints > 1;
  let deviceType = "Unknown";
  let os = "Unknown";
  if (/iPhone/.test(ua)) { deviceType = "iPhone"; os = "iOS"; }
  else if (/iPad/.test(ua) || touchMac) { deviceType = "iPad"; os = "iPadOS"; }
  else if (/Android/.test(ua)) { deviceType = /Mobile/.test(ua) ? "Android phone" : "Android tablet"; os = "Android"; }
  else if (/Windows/.test(ua)) { deviceType = "Windows PC"; os = "Windows"; }
  else if (/Macintosh/.test(ua)) { deviceType = "Mac"; os = "macOS"; }
  else if (/CrOS/.test(ua)) { deviceType = "Chromebook"; os = "ChromeOS"; }
  else if (/Linux/.test(ua)) { deviceType = "Linux PC"; os = "Linux"; }
  let browser = "Unknown";
  if (/Edg\//.test(ua)) browser = "Edge";
  else if (/OPR\//.test(ua)) browser = "Opera";
  else if (/SamsungBrowser/.test(ua)) browser = "Samsung Internet";
  else if (/CriOS|Chrome\//.test(ua)) browser = "Chrome";
  else if (/FxiOS|Firefox\//.test(ua)) browser = "Firefox";
  else if (/Safari\//.test(ua)) browser = "Safari";
  return { deviceType, os, browser };
}

// Silently reports customer-side visits once per browser session. Never on admin pages.
export function DeviceMonitor() {
  const { pathname } = useLocation();
  useEffect(() => {
    if (pathname.startsWith("/admin") || pathname.startsWith("/auth")) return;
    try {
      if (sessionStorage.getItem("dhl_dv_sent")) return;
      let id = localStorage.getItem("dhl_device_id");
      if (!id) {
        id = crypto.randomUUID();
        localStorage.setItem("dhl_device_id", id);
      }
      sessionStorage.setItem("dhl_dv_sent", "1");
      const info = detect();
      reportDeviceVisit({
        data: {
          deviceId: id,
          ...info,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone?.slice(0, 60),
          language: navigator.language?.slice(0, 20),
          screen: `${screen.width}x${screen.height}`,
          page: pathname.slice(0, 200),
        },
      }).catch(() => {});
    } catch {
      /* ignore */
    }
  }, [pathname]);
  return null;
}
