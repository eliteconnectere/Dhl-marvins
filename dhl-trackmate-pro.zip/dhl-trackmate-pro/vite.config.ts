// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

// --- Backend target: the project's own Supabase instance ---------------------
// The hosting platform injects its own SUPABASE_* / VITE_SUPABASE_* variables
// into process.env, and those take precedence over .env files. To make this app
// use OUR Supabase project instead, the values are pinned at build time here.
// The URL / publishable (anon) key are public by design; the service-role key is
// only read from the TARGET_SUPABASE_SERVICE_ROLE_KEY secret and is only ever
// referenced by server-side modules, so it never reaches the client bundle.
const SUPABASE_URL = "https://qlmevqlcgfcxkogerakm.supabase.co";
const SUPABASE_PROJECT_ID = "qlmevqlcgfcxkogerakm";
// Publishable (anon) key is public by design — pinned literally so the deployed
// build never falls back to an empty string when build-time env is unavailable.
const PUBLISHABLE_KEY =
  process.env.TARGET_SUPABASE_PUBLISHABLE_KEY ||
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  "sb_publishable_DnnYJYx_LWkxN0lgSGTVVQ_6pMgQBMK";
const SERVICE_ROLE_KEY = process.env.TARGET_SUPABASE_SERVICE_ROLE_KEY || "";

const s = (v: string) => JSON.stringify(v);


export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  vite: {
    define: {
      "import.meta.env.VITE_SUPABASE_URL": s(SUPABASE_URL),
      "import.meta.env.VITE_SUPABASE_PROJECT_ID": s(SUPABASE_PROJECT_ID),
      "import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY": s(PUBLISHABLE_KEY),
      "import.meta.env.VITE_SUPABASE_ANON_KEY": s(PUBLISHABLE_KEY),
      "process.env.SUPABASE_URL": s(SUPABASE_URL),
      "process.env.SUPABASE_PROJECT_ID": s(SUPABASE_PROJECT_ID),
      "process.env.SUPABASE_PUBLISHABLE_KEY": s(PUBLISHABLE_KEY),
      "process.env.SUPABASE_ANON_KEY": s(PUBLISHABLE_KEY),
      "process.env.SUPABASE_SERVICE_ROLE_KEY": s(SERVICE_ROLE_KEY),
    },
  },
});

