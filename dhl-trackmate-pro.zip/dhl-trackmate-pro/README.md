# DHL TrackMate Pro

A complete shipment tracking system: customers track packages in real time on a
live map, and admins manage shipments, locations, routes, and security alerts
from a protected dashboard.

## Tech Stack

- **Frontend:** React 19 + TanStack Start (file-based routing, SSR) + Vite 7
- **Styling:** Tailwind CSS v4 + shadcn/ui (Radix) components
- **Backend:** Supabase (Postgres database, auth, row-level security, RPC functions, pg_cron)
- **Maps:** Google Maps JavaScript API (live tracking map) + Google Routes/Geocoding APIs, with an OpenStreetMap (Nominatim) fallback for address lookup
- **Package manager:** Bun (npm also works)

## Project Structure

```
src/
  routes/            File-based pages (/, /track/:tn, /auth, /admin, /admin/:id)
  components/        UI components (TrackingMap, SecurityBell, DeviceMonitor, ...)
  lib/               Utilities + server functions (tracking, routing, geocoding, admin)
  integrations/      Supabase clients (browser + server)
  hooks/             React hooks
  styles.css         Tailwind v4 theme and design tokens
supabase/
  migrations/        All 23 database migrations (schema, RLS, RPCs, cron jobs)
  config.toml        Supabase local config
vite.config.ts       Build config (pins the backend URL/keys at build time)
```

## Prerequisites

- [Bun](https://bun.sh) (or Node.js 20+ with npm)
- A [Supabase](https://supabase.com) project (free tier works)
- A [Google Cloud](https://console.cloud.google.com) API key with these APIs enabled:
  - Maps JavaScript API (browser key)
  - Geocoding API + Routes API (server key)

## Setup

### 1. Install dependencies

```bash
bun install
# or: npm install
```

### 2. Configure environment variables

```bash
cp .env.example .env
```

Fill in your Supabase URL, publishable key, service-role key, and Google Maps
keys. See `.env.example` for the full list.

### 3. Set up the database

Apply the migrations to your Supabase project, in filename order. Either:

- **Supabase CLI:**
  ```bash
  supabase link --project-ref <your-project-ref>
  supabase db push
  ```
- **Or manually:** open the Supabase SQL Editor and run each file in
  `supabase/migrations/` in order (they are timestamped).

The migrations create the `shipments`, `tracking_events`, `scheduled_updates`,
`user_roles`, and device-alert tables, all RLS policies, the admin RPC
functions, the public tracking-lookup function, and the per-minute auto-route
cron job.

### 4. Create an admin account

1. In Supabase → Authentication → Users, add a user with your admin email and password.
2. Give that user the admin role:
   ```sql
   insert into public.user_roles (user_id, role)
   values ('<the-user-uuid>', 'admin');
   ```
3. Add the admin email to the `ADMIN_EMAILS` allowlist in `src/routes/auth.tsx`.

### 5. Run locally

```bash
bun dev
# or: npm run dev
```

Open http://localhost:5173 (Vite prints the exact port).

### 6. Build for production

```bash
bun run build
```

The build targets edge/serverless deployment (Cloudflare Workers-compatible via Nitro).

## Using the App

- **Customers** enter a tracking number on the home page (or visit
  `/track/<TRACKING_NUMBER>` directly) to see live location, route, history,
  and ETA.
- **Admins** sign in at `/auth` (or triple-tap the logo on the home page to
  reveal the hidden login), then manage shipments at `/admin`: create
  shipments, update status/location, schedule automatic updates, configure
  auto-routes with pause/resume, reroute destinations mid-transit, and review
  unusual-device security alerts via the bell icon.

## Notes

- Tracking numbers are auto-generated (format `DHL` + digits) and lookup is
  case-insensitive.
- The Google Maps browser key should be referrer-restricted to your production
  domain; on other origins the map shows an authorization warning.
- Never commit your real `.env` — it contains secret keys.
