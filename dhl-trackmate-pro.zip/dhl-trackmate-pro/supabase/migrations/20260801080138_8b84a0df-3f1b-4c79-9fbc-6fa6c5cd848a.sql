CREATE OR REPLACE FUNCTION public.admin_reroute_destination(
  _shipment_id uuid,
  _to_lat double precision,
  _to_lng double precision,
  _to_name text,
  _duration_seconds integer,
  _destination_text text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SET search_path TO 'public'
AS $function$
DECLARE
  r public.shipments%ROWTYPE;
  from_lat double precision;
  from_lng double precision;
  from_name text;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins may reroute shipments' USING ERRCODE = '42501';
  END IF;
  IF _duration_seconds IS NULL OR _duration_seconds < 30 THEN
    RAISE EXCEPTION 'Duration must be at least 30 seconds';
  END IF;
  IF _to_lat IS NULL OR _to_lng IS NULL THEN
    RAISE EXCEPTION 'A new destination with coordinates is required';
  END IF;

  SELECT * INTO r FROM public.shipments WHERE id = _shipment_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Shipment not found' USING ERRCODE = 'P0002';
  END IF;

  -- New leg starts exactly where the package currently is.
  from_lat := COALESCE(r.current_lat, r.route_from_lat);
  from_lng := COALESCE(r.current_lng, r.route_from_lng);
  from_name := COALESCE(r.current_location_name, r.route_from_name);

  IF from_lat IS NULL OR from_lng IS NULL THEN
    RAISE EXCEPTION 'Shipment has no current location to reroute from';
  END IF;

  PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

  UPDATE public.shipments SET
    route_from_lat = from_lat,
    route_from_lng = from_lng,
    route_from_name = from_name,
    route_to_lat = _to_lat,
    route_to_lng = _to_lng,
    route_to_name = _to_name,
    route_duration_seconds = _duration_seconds,
    route_elapsed_seconds = 0,
    route_completed = false,
    route_started_at = CASE WHEN r.route_paused THEN NULL ELSE now() END,
    destination = COALESCE(NULLIF(btrim(COALESCE(_destination_text, '')), ''), _to_name, destination)
  WHERE id = _shipment_id;

  INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
  VALUES (
    _shipment_id,
    r.status,
    from_name,
    from_lat,
    from_lng,
    'Rerouted — now heading to ' || COALESCE(_to_name, 'new destination')
  );
END;
$function$;