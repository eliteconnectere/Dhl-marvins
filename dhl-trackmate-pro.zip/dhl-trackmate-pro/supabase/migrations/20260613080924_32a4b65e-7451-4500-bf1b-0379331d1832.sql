-- Scheduled updates for shipments
CREATE TABLE public.scheduled_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid NOT NULL REFERENCES public.shipments(id) ON DELETE CASCADE,
  scheduled_for timestamptz NOT NULL,
  status text,
  location_name text,
  lat double precision,
  lng double precision,
  notes text,
  applied_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.scheduled_updates TO authenticated;
GRANT ALL ON public.scheduled_updates TO service_role;

ALTER TABLE public.scheduled_updates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins manage scheduled updates" ON public.scheduled_updates
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_scheduled_updates_due ON public.scheduled_updates(scheduled_for) WHERE applied_at IS NULL;

-- Function to process due scheduled updates
CREATE OR REPLACE FUNCTION public.process_scheduled_updates()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r record;
  n integer := 0;
  patch_status text;
  patch_loc text;
  patch_lat double precision;
  patch_lng double precision;
BEGIN
  FOR r IN
    SELECT * FROM public.scheduled_updates
    WHERE applied_at IS NULL AND scheduled_for <= now()
    ORDER BY scheduled_for ASC
  LOOP
    -- Apply to shipment
    UPDATE public.shipments s SET
      status = COALESCE(r.status, s.status),
      current_location_name = COALESCE(r.location_name, s.current_location_name),
      current_lat = COALESCE(r.lat, s.current_lat),
      current_lng = COALESCE(r.lng, s.current_lng)
    WHERE s.id = r.shipment_id;

    -- If only notes (no status/loc change) the trigger won't fire — insert explicit event
    IF r.notes IS NOT NULL AND r.status IS NULL AND r.location_name IS NULL THEN
      INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
      SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, r.notes
      FROM public.shipments s WHERE s.id = r.shipment_id;
    ELSIF r.notes IS NOT NULL THEN
      -- attach notes to the most recent auto-created event
      UPDATE public.tracking_events SET notes = r.notes
      WHERE id = (SELECT id FROM public.tracking_events WHERE shipment_id = r.shipment_id ORDER BY created_at DESC LIMIT 1);
    END IF;

    UPDATE public.scheduled_updates SET applied_at = now() WHERE id = r.id;
    n := n + 1;
  END LOOP;
  RETURN n;
END;
$$;

-- Schedule via pg_cron, every minute
CREATE EXTENSION IF NOT EXISTS pg_cron;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'process-scheduled-shipment-updates') THEN
    PERFORM cron.schedule('process-scheduled-shipment-updates', '* * * * *', $cron$SELECT public.process_scheduled_updates();$cron$);
  END IF;
END;
$$;