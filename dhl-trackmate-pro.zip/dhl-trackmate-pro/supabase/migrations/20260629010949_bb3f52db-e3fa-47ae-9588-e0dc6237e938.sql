REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
REVOKE ALL ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) FROM anon;
REVOKE ALL ON FUNCTION public.process_scheduled_updates() FROM anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.log_shipment_change() FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.touch_updated_at() FROM anon, authenticated;

GRANT EXECUTE ON FUNCTION public.get_shipment_by_tracking(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.process_scheduled_updates() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;