REVOKE ALL ON FUNCTION public.get_shipment_by_tracking(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.process_scheduled_updates() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;