ALTER TABLE public.shipments ADD COLUMN IF NOT EXISTS route_history jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE OR REPLACE FUNCTION public.admin_reroute_destination(_shipment_id uuid, _to_lat double precision, _to_lng double precision, _to_name text, _duration_seconds integer, _destination_text text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
DECLARE
  r public.shipments%ROWTYPE;
  from_lat double precision;
  from_lng double precision;
  from_name text;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins may reroute shipments' USING ERRCODE = '42501';
  END IF;
  IF _duration_seconds IS NULL OR _duration_seconds < 30 THEN
    RAISE EXCEPTION 'Duration must be at least 30 seconds';
  END IF;
  IF _to_lat IS NULL OR _to_lng IS NULL THEN
    RAISE EXCEPTION 'A new destination with coordinates is required';
  END IF;

  SELECT * INTO r FROM public.shipments WHERE id = _shipment_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Shipment not found' USING ERRCODE = 'P0002';
  END IF;

  from_lat := COALESCE(r.current_lat, r.route_from_lat);
  from_lng := COALESCE(r.current_lng, r.route_from_lng);
  from_name := COALESCE(r.current_location_name, r.route_from_name);

  IF from_lat IS NULL OR from_lng IS NULL THEN
    RAISE EXCEPTION 'Shipment has no current location to reroute from';
  END IF;

  PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

  UPDATE public.shipments SET
    route_history = CASE
      WHEN r.route_from_lat IS NOT NULL AND r.route_from_lng IS NOT NULL
        THEN COALESCE(r.route_history, '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
          'from_lat', r.route_from_lat,
          'from_lng', r.route_from_lng,
          'from_name', r.route_from_name,
          'to_lat', from_lat,
          'to_lng', from_lng,
          'to_name', from_name
        ))
      ELSE COALESCE(r.route_history, '[]'::jsonb)
    END,
    route_from_lat = from_lat,
    route_from_lng = from_lng,
    route_from_name = from_name,
    route_to_lat = _to_lat,
    route_to_lng = _to_lng,
    route_to_name = _to_name,
    route_duration_seconds = _duration_seconds,
    route_elapsed_seconds = 0,
    route_completed = false,
    route_started_at = CASE WHEN r.route_paused THEN NULL ELSE now() END,
    destination = COALESCE(NULLIF(btrim(COALESCE(_destination_text, '')), ''), _to_name, destination)
  WHERE id = _shipment_id;

  INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
  VALUES (
    _shipment_id,
    r.status,
    from_name,
    from_lat,
    from_lng,
    'Rerouted — now heading to ' || COALESCE(_to_name, 'new destination')
  );
END;
$function$;

CREATE OR REPLACE FUNCTION public.admin_set_auto_route(_shipment_id uuid, _from_lat double precision, _from_lng double precision, _from_name text, _to_lat double precision, _to_lng double precision, _to_name text, _duration_seconds integer, _start_now boolean DEFAULT true)
 RETURNS void
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins may configure auto-routes' USING ERRCODE = '42501';
  END IF;
  IF _duration_seconds IS NULL OR _duration_seconds < 30 THEN
    RAISE EXCEPTION 'Duration must be at least 30 seconds';
  END IF;

  PERFORM set_config('app.skip_shipment_auto_log', 'true', true);
  UPDATE public.shipments SET
    route_history = '[]'::jsonb,
    route_from_lat = _from_lat,
    route_from_lng = _from_lng,
    route_from_name = _from_name,
    route_to_lat = _to_lat,
    route_to_lng = _to_lng,
    route_to_name = _to_name,
    route_duration_seconds = _duration_seconds,
    route_elapsed_seconds = 0,
    route_paused = NOT _start_now,
    route_completed = false,
    route_started_at = CASE WHEN _start_now THEN now() ELSE NULL END,
    current_lat = _from_lat,
    current_lng = _from_lng,
    current_location_name = COALESCE(_from_name, current_location_name)
  WHERE id = _shipment_id;

  INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
  SELECT id, status, COALESCE(_from_name, current_location_name), _from_lat, _from_lng,
         'Auto-route started toward ' || COALESCE(_to_name, 'destination')
  FROM public.shipments WHERE id = _shipment_id;
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_shipment_by_tracking(_tracking text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  s public.shipments;
  events jsonb;
BEGIN
  SELECT * INTO s FROM public.shipments WHERE tracking_number = upper(trim(_tracking)) LIMIT 1;
  IF NOT FOUND THEN RETURN NULL; END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(e) ORDER BY e.created_at DESC), '[]'::jsonb)
    INTO events FROM public.tracking_events e WHERE e.shipment_id = s.id;
  RETURN jsonb_build_object(
    'id', s.id,
    'tracking_number', s.tracking_number,
    'status', s.status,
    'sender_name', s.sender_name,
    'recipient_name', s.recipient_name,
    'recipient_address', s.recipient_address,
    'origin', s.origin,
    'destination', s.destination,
    'package_description', s.package_description,
    'weight_kg', s.weight_kg,
    'current_location_name', s.current_location_name,
    'current_lat', s.current_lat,
    'current_lng', s.current_lng,
    'estimated_delivery', s.estimated_delivery,
    'created_at', s.created_at,
    'updated_at', s.updated_at,
    'route_from_lat', s.route_from_lat,
    'route_from_lng', s.route_from_lng,
    'route_from_name', s.route_from_name,
    'route_to_lat', s.route_to_lat,
    'route_to_lng', s.route_to_lng,
    'route_to_name', s.route_to_name,
    'route_duration_seconds', s.route_duration_seconds,
    'route_started_at', s.route_started_at,
    'route_elapsed_seconds', s.route_elapsed_seconds,
    'route_paused', s.route_paused,
    'route_completed', s.route_completed,
    'route_history', COALESCE(s.route_history, '[]'::jsonb),
    'animation_smoothness', s.animation_smoothness,
    'animation_easing', s.animation_easing,
    'events', events
  );
END;
$function$;