DROP TRIGGER IF EXISTS shipments_touch_updated_at ON public.shipments;
CREATE TRIGGER shipments_touch_updated_at
BEFORE UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS shipments_log_change ON public.shipments;
CREATE TRIGGER shipments_log_change
AFTER INSERT OR UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.log_shipment_change();

INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, created_at)
SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, s.created_at
FROM public.shipments s
WHERE NOT EXISTS (
  SELECT 1 FROM public.tracking_events e WHERE e.shipment_id = s.id
);