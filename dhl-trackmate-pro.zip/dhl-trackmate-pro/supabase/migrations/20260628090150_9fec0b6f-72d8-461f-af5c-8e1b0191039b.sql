CREATE OR REPLACE FUNCTION public.admin_update_shipment(
  _shipment_id uuid,
  _status text DEFAULT NULL,
  _location_name text DEFAULT NULL,
  _location_provided boolean DEFAULT false,
  _lat double precision DEFAULT NULL,
  _lng double precision DEFAULT NULL,
  _estimated_delivery timestamptz DEFAULT NULL,
  _set_estimated_delivery boolean DEFAULT false,
  _notes text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  before_row public.shipments%ROWTYPE;
  after_row public.shipments%ROWTYPE;
  next_status text;
  next_location text;
  next_lat double precision;
  next_lng double precision;
  clean_notes text;
  changed boolean := false;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only authorized DHL admins can update shipments' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO before_row
  FROM public.shipments
  WHERE id = _shipment_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Shipment not found' USING ERRCODE = 'P0002';
  END IF;

  next_status := COALESCE(NULLIF(btrim(_status), ''), before_row.status);

  IF _location_provided THEN
    next_location := NULLIF(btrim(COALESCE(_location_name, '')), '');
    IF _lat IS NOT NULL AND _lng IS NOT NULL THEN
      next_lat := _lat;
      next_lng := _lng;
    ELSE
      next_lat := NULL;
      next_lng := NULL;
    END IF;
  ELSE
    next_location := before_row.current_location_name;
    next_lat := before_row.current_lat;
    next_lng := before_row.current_lng;
  END IF;

  clean_notes := NULLIF(btrim(COALESCE(_notes, '')), '');

  changed :=
    next_status IS DISTINCT FROM before_row.status OR
    next_location IS DISTINCT FROM before_row.current_location_name OR
    next_lat IS DISTINCT FROM before_row.current_lat OR
    next_lng IS DISTINCT FROM before_row.current_lng OR
    (_set_estimated_delivery AND _estimated_delivery IS DISTINCT FROM before_row.estimated_delivery);

  IF changed THEN
    PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

    UPDATE public.shipments
    SET
      status = next_status,
      current_location_name = next_location,
      current_lat = next_lat,
      current_lng = next_lng,
      estimated_delivery = CASE WHEN _set_estimated_delivery THEN _estimated_delivery ELSE estimated_delivery END
    WHERE id = before_row.id
    RETURNING * INTO after_row;
  ELSE
    after_row := before_row;
  END IF;

  IF changed OR clean_notes IS NOT NULL THEN
    INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
    VALUES (before_row.id, after_row.status, after_row.current_location_name, after_row.current_lat, after_row.current_lng, clean_notes);
  END IF;

  RETURN to_jsonb(after_row);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamptz, boolean, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamptz, boolean, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamptz, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamptz, boolean, text) TO service_role;