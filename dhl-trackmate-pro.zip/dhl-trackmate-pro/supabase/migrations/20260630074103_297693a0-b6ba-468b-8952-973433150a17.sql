
-- Auto-route animation columns on shipments
ALTER TABLE public.shipments
  ADD COLUMN IF NOT EXISTS route_from_lat double precision,
  ADD COLUMN IF NOT EXISTS route_from_lng double precision,
  ADD COLUMN IF NOT EXISTS route_from_name text,
  ADD COLUMN IF NOT EXISTS route_to_lat double precision,
  ADD COLUMN IF NOT EXISTS route_to_lng double precision,
  ADD COLUMN IF NOT EXISTS route_to_name text,
  ADD COLUMN IF NOT EXISTS route_duration_seconds integer,
  ADD COLUMN IF NOT EXISTS route_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS route_elapsed_seconds integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS route_paused boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS route_completed boolean NOT NULL DEFAULT false;

-- Tick function: linearly interpolate current_lat/lng based on elapsed time
CREATE OR REPLACE FUNCTION public.tick_auto_routes()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r record;
  elapsed integer;
  progress double precision;
  new_lat double precision;
  new_lng double precision;
  n integer := 0;
BEGIN
  FOR r IN
    SELECT * FROM public.shipments
    WHERE route_duration_seconds IS NOT NULL
      AND route_from_lat IS NOT NULL AND route_to_lat IS NOT NULL
      AND route_paused = false
      AND route_completed = false
      AND route_started_at IS NOT NULL
  LOOP
    elapsed := r.route_elapsed_seconds + GREATEST(0, EXTRACT(EPOCH FROM (now() - r.route_started_at))::int);
    IF elapsed >= r.route_duration_seconds THEN
      progress := 1.0;
    ELSE
      progress := elapsed::double precision / NULLIF(r.route_duration_seconds, 0);
    END IF;

    new_lat := r.route_from_lat + (r.route_to_lat - r.route_from_lat) * progress;
    new_lng := r.route_from_lng + (r.route_to_lng - r.route_from_lng) * progress;

    PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

    IF progress >= 1.0 THEN
      UPDATE public.shipments SET
        current_lat = r.route_to_lat,
        current_lng = r.route_to_lng,
        current_location_name = COALESCE(r.route_to_name, current_location_name),
        route_completed = true,
        route_elapsed_seconds = r.route_duration_seconds,
        route_started_at = NULL
      WHERE id = r.id;

      INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
      VALUES (r.id, r.status, COALESCE(r.route_to_name, r.current_location_name), r.route_to_lat, r.route_to_lng, 'Auto-route arrived');
    ELSE
      UPDATE public.shipments SET
        current_lat = new_lat,
        current_lng = new_lng
      WHERE id = r.id;
    END IF;
    n := n + 1;
  END LOOP;
  RETURN n;
END;
$$;

REVOKE ALL ON FUNCTION public.tick_auto_routes() FROM public;
GRANT EXECUTE ON FUNCTION public.tick_auto_routes() TO authenticated, service_role;

-- Admin route control RPC
CREATE OR REPLACE FUNCTION public.admin_set_auto_route(
  _shipment_id uuid,
  _from_lat double precision,
  _from_lng double precision,
  _from_name text,
  _to_lat double precision,
  _to_lng double precision,
  _to_name text,
  _duration_seconds integer,
  _start_now boolean DEFAULT true
) RETURNS void
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins may configure auto-routes' USING ERRCODE = '42501';
  END IF;
  IF _duration_seconds IS NULL OR _duration_seconds < 30 THEN
    RAISE EXCEPTION 'Duration must be at least 30 seconds';
  END IF;

  PERFORM set_config('app.skip_shipment_auto_log', 'true', true);
  UPDATE public.shipments SET
    route_from_lat = _from_lat,
    route_from_lng = _from_lng,
    route_from_name = _from_name,
    route_to_lat = _to_lat,
    route_to_lng = _to_lng,
    route_to_name = _to_name,
    route_duration_seconds = _duration_seconds,
    route_elapsed_seconds = 0,
    route_paused = NOT _start_now,
    route_completed = false,
    route_started_at = CASE WHEN _start_now THEN now() ELSE NULL END,
    current_lat = _from_lat,
    current_lng = _from_lng,
    current_location_name = COALESCE(_from_name, current_location_name)
  WHERE id = _shipment_id;

  INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
  SELECT id, status, COALESCE(_from_name, current_location_name), _from_lat, _from_lng,
         'Auto-route started toward ' || COALESCE(_to_name, 'destination')
  FROM public.shipments WHERE id = _shipment_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_pause_auto_route(_shipment_id uuid)
RETURNS void LANGUAGE plpgsql SET search_path = public AS $$
DECLARE r public.shipments%ROWTYPE;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins' USING ERRCODE = '42501'; END IF;
  SELECT * INTO r FROM public.shipments WHERE id = _shipment_id FOR UPDATE;
  IF r.route_paused OR r.route_started_at IS NULL THEN RETURN; END IF;
  UPDATE public.shipments SET
    route_elapsed_seconds = route_elapsed_seconds + GREATEST(0, EXTRACT(EPOCH FROM (now() - route_started_at))::int),
    route_started_at = NULL,
    route_paused = true
  WHERE id = _shipment_id;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_resume_auto_route(_shipment_id uuid)
RETURNS void LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins' USING ERRCODE = '42501'; END IF;
  UPDATE public.shipments SET
    route_paused = false,
    route_started_at = now()
  WHERE id = _shipment_id AND route_completed = false;
END; $$;

CREATE OR REPLACE FUNCTION public.admin_clear_auto_route(_shipment_id uuid)
RETURNS void LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins' USING ERRCODE = '42501'; END IF;
  UPDATE public.shipments SET
    route_from_lat = NULL, route_from_lng = NULL, route_from_name = NULL,
    route_to_lat = NULL, route_to_lng = NULL, route_to_name = NULL,
    route_duration_seconds = NULL, route_started_at = NULL,
    route_elapsed_seconds = 0, route_paused = false, route_completed = false
  WHERE id = _shipment_id;
END; $$;

-- Cron tick every minute (interpolation happens server-side; clients interpolate live too)
DO $$ BEGIN
  PERFORM cron.unschedule('tick-auto-routes');
EXCEPTION WHEN OTHERS THEN NULL; END $$;

SELECT cron.schedule('tick-auto-routes', '* * * * *', $$ SELECT public.tick_auto_routes(); $$);

-- Update get_shipment_by_tracking to expose route fields
CREATE OR REPLACE FUNCTION public.get_shipment_by_tracking(_tracking text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  s public.shipments;
  events jsonb;
BEGIN
  SELECT * INTO s FROM public.shipments WHERE tracking_number = upper(trim(_tracking)) LIMIT 1;
  IF NOT FOUND THEN RETURN NULL; END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(e) ORDER BY e.created_at DESC), '[]'::jsonb)
    INTO events FROM public.tracking_events e WHERE e.shipment_id = s.id;
  RETURN jsonb_build_object(
    'id', s.id,
    'tracking_number', s.tracking_number,
    'status', s.status,
    'sender_name', s.sender_name,
    'recipient_name', s.recipient_name,
    'recipient_address', s.recipient_address,
    'origin', s.origin,
    'destination', s.destination,
    'package_description', s.package_description,
    'weight_kg', s.weight_kg,
    'current_location_name', s.current_location_name,
    'current_lat', s.current_lat,
    'current_lng', s.current_lng,
    'estimated_delivery', s.estimated_delivery,
    'created_at', s.created_at,
    'updated_at', s.updated_at,
    'route_from_lat', s.route_from_lat,
    'route_from_lng', s.route_from_lng,
    'route_from_name', s.route_from_name,
    'route_to_lat', s.route_to_lat,
    'route_to_lng', s.route_to_lng,
    'route_to_name', s.route_to_name,
    'route_duration_seconds', s.route_duration_seconds,
    'route_started_at', s.route_started_at,
    'route_elapsed_seconds', s.route_elapsed_seconds,
    'route_paused', s.route_paused,
    'route_completed', s.route_completed,
    'events', events
  );
END;
$function$;
