CREATE TABLE IF NOT EXISTS public.known_devices (
  device_id text PRIMARY KEY,
  countries text[] NOT NULL DEFAULT '{}',
  device_type text, os text, browser text,
  first_seen timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  visits integer NOT NULL DEFAULT 1
);
GRANT ALL ON public.known_devices TO service_role;
ALTER TABLE public.known_devices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read devices" ON public.known_devices FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
GRANT SELECT ON public.known_devices TO authenticated;

CREATE TABLE IF NOT EXISTS public.security_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  kind text NOT NULL,
  device_id text,
  device_type text, os text, browser text,
  country text, region text, city text, timezone text, language text, screen text, page text,
  read_at timestamptz
);
GRANT SELECT, UPDATE, DELETE ON public.security_alerts TO authenticated;
GRANT ALL ON public.security_alerts TO service_role;
ALTER TABLE public.security_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read alerts" ON public.security_alerts FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update alerts" ON public.security_alerts FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete alerts" ON public.security_alerts FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE INDEX IF NOT EXISTS security_alerts_created_idx ON public.security_alerts(created_at DESC);

CREATE OR REPLACE FUNCTION public.record_device_visit(
  _device_id text, _device_type text, _os text, _browser text,
  _country text, _region text, _city text, _timezone text, _language text, _screen text, _page text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE d public.known_devices; k text := NULL; c text := NULLIF(left(_country,80),'');
BEGIN
  IF _device_id IS NULL OR length(_device_id) < 8 OR length(_device_id) > 80 THEN RETURN; END IF;
  SELECT * INTO d FROM public.known_devices WHERE device_id = _device_id;
  IF NOT FOUND THEN
    INSERT INTO public.known_devices(device_id, countries, device_type, os, browser)
      VALUES (_device_id, CASE WHEN c IS NULL THEN '{}' ELSE ARRAY[c] END, left(_device_type,40), left(_os,40), left(_browser,40));
    k := 'new_device';
  ELSE
    UPDATE public.known_devices SET last_seen = now(), visits = visits + 1,
      countries = CASE WHEN c IS NOT NULL AND NOT (c = ANY(countries)) THEN array_append(countries, c) ELSE countries END
      WHERE device_id = _device_id;
    IF c IS NOT NULL AND cardinality(d.countries) > 0 AND NOT (c = ANY(d.countries)) THEN k := 'new_region'; END IF;
  END IF;
  IF k IS NOT NULL AND (SELECT count(*) FROM public.security_alerts WHERE created_at > now() - interval '1 hour') < 200 THEN
    INSERT INTO public.security_alerts(kind, device_id, device_type, os, browser, country, region, city, timezone, language, screen, page)
    VALUES (k, _device_id, left(_device_type,40), left(_os,40), left(_browser,40), c, left(NULLIF(_region,''),80), left(NULLIF(_city,''),80),
      left(NULLIF(_timezone,''),60), left(NULLIF(_language,''),20), left(NULLIF(_screen,''),20), left(NULLIF(_page,''),200));
  END IF;
  DELETE FROM public.security_alerts WHERE created_at < now() - interval '90 days';
END $$;
REVOKE ALL ON FUNCTION public.record_device_visit(text,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.record_device_visit(text,text,text,text,text,text,text,text,text,text,text) TO anon, authenticated;
