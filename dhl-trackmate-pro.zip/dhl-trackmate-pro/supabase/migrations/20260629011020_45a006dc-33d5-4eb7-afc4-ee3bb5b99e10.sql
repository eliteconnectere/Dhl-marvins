ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM anon;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM authenticated;

GRANT EXECUTE ON FUNCTION public.get_shipment_by_tracking(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.process_scheduled_updates() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;