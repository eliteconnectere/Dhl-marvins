CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.log_shipment_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  IF current_setting('app.skip_shipment_auto_log', true) = 'true' THEN
    RETURN NEW;
  END IF;

  IF (TG_OP = 'INSERT') OR
     (NEW.status IS DISTINCT FROM OLD.status) OR
     (NEW.current_location_name IS DISTINCT FROM OLD.current_location_name) OR
     (NEW.current_lat IS DISTINCT FROM OLD.current_lat) OR
     (NEW.current_lng IS DISTINCT FROM OLD.current_lng) THEN
    INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng)
    VALUES (NEW.id, NEW.status, NEW.current_location_name, NEW.current_lat, NEW.current_lng);
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS shipments_touch ON public.shipments;
DROP TRIGGER IF EXISTS shipments_touch_updated_at ON public.shipments;
CREATE TRIGGER shipments_touch_updated_at
BEFORE UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.touch_updated_at();

DROP TRIGGER IF EXISTS shipments_log_insert ON public.shipments;
DROP TRIGGER IF EXISTS shipments_log_update ON public.shipments;
DROP TRIGGER IF EXISTS shipments_log_change ON public.shipments;
CREATE TRIGGER shipments_log_change
AFTER INSERT OR UPDATE ON public.shipments
FOR EACH ROW
EXECUTE FUNCTION public.log_shipment_change();

INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes, created_at)
SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, 'Initial tracking history restored', s.created_at
FROM public.shipments s
WHERE NOT EXISTS (
  SELECT 1 FROM public.tracking_events e WHERE e.shipment_id = s.id
);