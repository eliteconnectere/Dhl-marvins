CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $function$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$function$;

CREATE OR REPLACE FUNCTION public.admin_update_shipment(
  _shipment_id uuid,
  _status text DEFAULT NULL::text,
  _location_name text DEFAULT NULL::text,
  _location_provided boolean DEFAULT false,
  _lat double precision DEFAULT NULL::double precision,
  _lng double precision DEFAULT NULL::double precision,
  _estimated_delivery timestamp with time zone DEFAULT NULL::timestamp with time zone,
  _set_estimated_delivery boolean DEFAULT false,
  _notes text DEFAULT NULL::text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $function$
DECLARE
  before_row public.shipments%ROWTYPE;
  after_row public.shipments%ROWTYPE;
  next_status text;
  next_location text;
  next_lat double precision;
  next_lng double precision;
  clean_notes text;
  changed boolean := false;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only authorized DHL admins can update shipments' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO before_row
  FROM public.shipments
  WHERE id = _shipment_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Shipment not found' USING ERRCODE = 'P0002';
  END IF;

  next_status := COALESCE(NULLIF(btrim(_status), ''), before_row.status);

  IF _location_provided THEN
    next_location := NULLIF(btrim(COALESCE(_location_name, '')), '');
    IF _lat IS NOT NULL AND _lng IS NOT NULL THEN
      next_lat := _lat;
      next_lng := _lng;
    ELSE
      next_lat := NULL;
      next_lng := NULL;
    END IF;
  ELSE
    next_location := before_row.current_location_name;
    next_lat := before_row.current_lat;
    next_lng := before_row.current_lng;
  END IF;

  clean_notes := NULLIF(btrim(COALESCE(_notes, '')), '');

  changed :=
    next_status IS DISTINCT FROM before_row.status OR
    next_location IS DISTINCT FROM before_row.current_location_name OR
    next_lat IS DISTINCT FROM before_row.current_lat OR
    next_lng IS DISTINCT FROM before_row.current_lng OR
    (_set_estimated_delivery AND _estimated_delivery IS DISTINCT FROM before_row.estimated_delivery);

  IF changed THEN
    PERFORM set_config('app.skip_shipment_auto_log', 'true', true);

    UPDATE public.shipments
    SET
      status = next_status,
      current_location_name = next_location,
      current_lat = next_lat,
      current_lng = next_lng,
      estimated_delivery = CASE WHEN _set_estimated_delivery THEN _estimated_delivery ELSE estimated_delivery END
    WHERE id = before_row.id
    RETURNING * INTO after_row;
  ELSE
    after_row := before_row;
  END IF;

  IF changed OR clean_notes IS NOT NULL THEN
    INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
    VALUES (before_row.id, after_row.status, after_row.current_location_name, after_row.current_lat, after_row.current_lng, clean_notes);
  END IF;

  RETURN to_jsonb(after_row);
END;
$function$;

CREATE OR REPLACE FUNCTION public.process_scheduled_updates()
RETURNS integer
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $function$
DECLARE
  r record;
  n integer := 0;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only authorized DHL admins can process scheduled updates' USING ERRCODE = '42501';
  END IF;

  FOR r IN
    SELECT * FROM public.scheduled_updates
    WHERE applied_at IS NULL AND scheduled_for <= now()
    ORDER BY scheduled_for ASC
  LOOP
    UPDATE public.shipments s SET
      status = COALESCE(r.status, s.status),
      current_location_name = COALESCE(r.location_name, s.current_location_name),
      current_lat = CASE WHEN r.location_name IS NOT NULL THEN r.lat ELSE s.current_lat END,
      current_lng = CASE WHEN r.location_name IS NOT NULL THEN r.lng ELSE s.current_lng END
    WHERE s.id = r.shipment_id;

    IF r.notes IS NOT NULL AND r.status IS NULL AND r.location_name IS NULL THEN
      INSERT INTO public.tracking_events (shipment_id, status, location_name, lat, lng, notes)
      SELECT s.id, s.status, s.current_location_name, s.current_lat, s.current_lng, r.notes
      FROM public.shipments s WHERE s.id = r.shipment_id;
    ELSIF r.notes IS NOT NULL THEN
      UPDATE public.tracking_events SET notes = r.notes
      WHERE id = (
        SELECT id
        FROM public.tracking_events
        WHERE shipment_id = r.shipment_id
        ORDER BY created_at DESC
        LIMIT 1
      );
    END IF;

    UPDATE public.scheduled_updates SET applied_at = now() WHERE id = r.id;
    n := n + 1;
  END LOOP;
  RETURN n;
END;
$function$;

REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_update_shipment(uuid, text, text, boolean, double precision, double precision, timestamp with time zone, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.process_scheduled_updates() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;